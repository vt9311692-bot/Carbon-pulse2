import './calculation.test';
import './simulation.test';
