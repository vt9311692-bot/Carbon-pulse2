import { describe, test, expect, beforeAll } from './vitest-mock';
import crypto from 'crypto';
import { encryptData, decryptData } from '../utils/crypto';

// Polyfill environment for Web Crypto & localStorage in Node/Vitest
beforeAll(() => {
  if (!globalThis.crypto) {
    // @ts-ignore
    globalThis.crypto = crypto.webcrypto;
  }
  
  if (typeof window === 'undefined') {
    // @ts-ignore
    globalThis.window = { crypto: globalThis.crypto };
  }

  const store: Record<string, string> = {};
  // @ts-ignore
  globalThis.localStorage = {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => { store[key] = value; },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { for (const k in store) delete store[k]; }
  };
});

describe('Secure State Encryption Suite', () => {

  test('Should encrypt and decrypt data successfully matching plaintext', async () => {
    const rawData = JSON.stringify({
      carDistanceWeekly: 120,
      carFuelType: 'Hybrid',
      electricityMonthlyKwh: 350
    });

    const encrypted = await encryptData(rawData);
    expect(encrypted).toBeDefined();
    expect(encrypted).not.toBe(rawData);

    const decrypted = await decryptData(encrypted);
    expect(decrypted).toBe(rawData);
    expect(JSON.parse(decrypted).carDistanceWeekly).toBe(120);
  });

  test('Should fail decryption for corrupted data payload', async () => {
    const corruptedBase64 = 'cGFzc3dvcmQxMjM='; // base64 of 'password123'
    await expect(decryptData(corruptedBase64)).rejects.toThrow();
  });

  test('Should generate unique key on first load and reuse it subsequent times', async () => {
    const data = "test-string";
    const enc1 = await encryptData(data);
    const enc2 = await encryptData(data);
    
    // Decrypting enc1 and enc2 should both work, indicating same key is used
    expect(await decryptData(enc1)).toBe(data);
    expect(await decryptData(enc2)).toBe(data);
  });

});

describe('Input Sanitization & Boundary Protections', () => {

  // Pure functions recreating component sanitization for testing verification
  const sanitizeNumber = (val: string, maxLimit: number = 100000): number => {
    if (val.trim().startsWith('-')) return 0;
    const cleanStr = val.replace(/[^0-9.]/g, '');
    const parts = cleanStr.split('.');
    const singleDotStr = parts.length > 2 
      ? `${parts[0]}.${parts.slice(1).join('')}` 
      : cleanStr;
      
    const parsed = parseFloat(singleDotStr);
    if (isNaN(parsed) || parsed <= 0) return 0;
    return Math.min(parsed, maxLimit);
  };

  test('Should remove alphabetic and special characters from numeric inputs', () => {
    const badInput = '123abc45!@#';
    const result = sanitizeNumber(badInput);
    expect(result).toBe(12345);
  });

  test('Should allow single decimal point and remove duplicates', () => {
    const doubleDotInput = '12.34.56';
    const result = sanitizeNumber(doubleDotInput);
    expect(result).toBe(12.3456);
  });

  test('Should cap inputs at designated maximum limits', () => {
    const massiveInput = '99999999';
    const cappedResult = sanitizeNumber(massiveInput, 10000);
    expect(cappedResult).toBe(10000);
  });

  test('Should fallback to 0 for negative numbers and non-numeric inputs', () => {
    expect(sanitizeNumber('-150')).toBe(0);
    expect(sanitizeNumber('text')).toBe(0);
  });

});

describe('Ecosystem Physics Calculations', () => {

  test('Mass scales correctly with emissions data', () => {
    const transportEmissions = 3200; // 3.2 tons
    const mass = transportEmissions / 1000;
    
    // Width sizing logic in simulation: Math.max(35, Math.min(85, 35 + mass * 12))
    const size = Math.max(35, Math.min(85, 35 + mass * 12));
    
    expect(mass).toBe(3.2);
    expect(size).toBe(35 + 3.2 * 12); // 73.4
  });

  test('Mass limits correctly at lower and upper bounds', () => {
    const zeroEmissions = 0;
    const massZero = zeroEmissions / 1000;
    const sizeZero = Math.max(35, Math.min(85, 35 + massZero * 12));
    expect(sizeZero).toBe(35); // Lower bound

    const hugeEmissions = 500000; // 500 tons
    const massHuge = hugeEmissions / 1000;
    const sizeHuge = Math.max(35, Math.min(85, 35 + massHuge * 12));
    expect(sizeHuge).toBe(85); // Upper bound capped
  });

});

describe('Authentication & Token Signature Verification', () => {

  const SECRET = 'test-server-secret-32-chars-long';

  const hashPassword = (password: string, salt: string): string => {
    return crypto.createHash('sha256').update(password + salt).digest('hex');
  };

  const generateToken = (userId: number, email: string): string => {
    const msg = `${userId}:${email}`;
    const signature = crypto.createHmac('sha256', SECRET).update(msg).digest('hex');
    return `${userId}:${email}:${signature}`;
  };

  const verifyToken = (token: string): { userId: number; email: string } | null => {
    try {
      const parts = token.split(':');
      if (parts.length !== 3) return null;
      const [userIdStr, email, signature] = parts;
      const userId = parseInt(userIdStr);
      const expected = crypto.createHmac('sha256', SECRET).update(`${userId}:${email}`).digest('hex');
      if (expected === signature) {
        return { userId, email };
      }
    } catch {}
    return null;
  };

  test('Password hashing produces distinct results for different salts', () => {
    const pass = 'supersecret';
    const salt1 = 'saltA';
    const salt2 = 'saltB';
    const h1 = hashPassword(pass, salt1);
    const h2 = hashPassword(pass, salt2);
    expect(h1).toBeDefined();
    expect(h2).toBeDefined();
    expect(h1).not.toBe(h2);
    expect(h1.length).toBe(64); // SHA-256 is 64 hex characters
  });

  test('Token signatures are validated correctly and resist tampering', () => {
    const userId = 42;
    const email = 'user@test.com';
    const token = generateToken(userId, email);

    // Verify valid token
    const decoded = verifyToken(token);
    expect(decoded).toBeDefined();
    expect(decoded?.userId).toBe(userId);
    expect(decoded?.email).toBe(email);

    // Tampered token user ID
    const tamperedUserToken = token.replace('42:', '43:');
    expect(verifyToken(tamperedUserToken)).toBe(null);

    // Tampered signature
    const tamperedSigToken = token.slice(0, -5) + '00000';
    expect(verifyToken(tamperedSigToken)).toBe(null);
  });

});

