import { test as nodeTest, describe as nodeDescribe, before as nodeBefore } from 'node:test';
import assert from 'node:assert';

export const describe = nodeDescribe;
export const test = nodeTest;
export const it = nodeTest;
export const beforeAll = nodeBefore;
export const beforeEach = (fn: any) => {};
export const afterAll = (fn: any) => {};
export const afterEach = (fn: any) => {};

export const vi = {
  fn: (impl?: (...args: any[]) => any) => {
    const mock = (...args: any[]) => {
      mock.mock.calls.push(args);
      return impl ? impl(...args) : undefined;
    };
    mock.mock = { calls: [] as any[][] };
    return mock;
  }
};

export const expect = (actual: any) => {
  const matchers = {
    toBe: (expected: any) => assert.strictEqual(actual, expected),
    toEqual: (expected: any) => assert.deepStrictEqual(actual, expected),
    toBeCloseTo: (expected: number, precision = 2) => {
      const diff = Math.abs(actual - expected);
      const tolerance = Math.pow(10, -precision) / 2;
      assert.ok(diff < tolerance, `Expected ${actual} to be close to ${expected} (diff: ${diff}, tolerance: ${tolerance})`);
    },
    toBeDefined: () => assert.ok(actual !== undefined && actual !== null),
    toBeUndefined: () => assert.ok(actual === undefined),
    toBeTruthy: () => assert.ok(!!actual),
    toBeFalsy: () => assert.ok(!actual),
    not: {
      toBe: (expected: any) => assert.notStrictEqual(actual, expected),
      toEqual: (expected: any) => assert.notDeepStrictEqual(actual, expected),
    },
    rejects: {
      toThrow: async () => {
        let threw = false;
        try {
          const res = typeof actual === 'function' ? actual() : actual;
          await res;
        } catch {
          threw = true;
        }
        assert.ok(threw, "Expected promise to reject/throw");
      }
    }
  };
  return matchers;
};
