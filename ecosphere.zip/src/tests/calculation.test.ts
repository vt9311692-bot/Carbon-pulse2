import { describe, test, expect } from './vitest-mock';
import { 
  calculateTransportEmissions, 
  calculateEnergyEmissions, 
  calculateDietEmissions, 
  calculateGoodsAndWasteEmissions,
  calculateTotalCarbonFootprint,
  EstimatorInputs
} from '../utils/emissionFactors';

describe('Carbon Footprint Calculation Suite', () => {

  test('Transport Emission Calculation', () => {
    // Petrol car: 100km/week * 52 weeks * 0.170 kg/km = 884.0 kg
    // Transit: 50km/week * 52 weeks * 0.030 kg/km = 78.0 kg
    // Flights: 2 short (300kg) + 1 long (800kg) = 1100.0 kg
    // Total: 884 + 78 + 1100 = 2062.0 kg
    const transportRes = calculateTransportEmissions(100, 'Petrol', 50, 2, 1);
    expect(transportRes).toBeCloseTo(2062.0, 1);
  });

  test('Home Energy Emission Calculation', () => {
    // Electricity: 200 kWh/month * 12 * 0.380 kg/kWh * (1 - 0.40) = 547.2 kg
    // Heating: Natural Gas, 500 kWh/month * 12 * 0.200 kg/kWh = 1200.0 kg
    // Total: 547.2 + 1200.0 = 1747.2 kg
    const energyRes = calculateEnergyEmissions(200, 40, 'Natural Gas', 500);
    expect(energyRes).toBeCloseTo(1747.2, 1);
  });

  test('Diet Emission Calculation (Vegan, 50% Local)', () => {
    // Vegan: 700.0 kg
    // Local share: 50% => 5% reduction (700 * 0.95 = 665.0 kg)
    const dietRes = calculateDietEmissions('Vegan', 50);
    expect(dietRes).toBeCloseTo(665.0, 1);
  });

  test('Goods & Waste Calculation (Compost + Most Recycling)', () => {
    // Spending: $200/month * 12 * 0.120 kg/$ = 288.0 kg
    // Waste: Base 500.0 kg, Composting (10%), Recycling "Most" (20%) => 30% reduction (500 * 0.70 = 350.0 kg)
    // Total: 288 + 350 = 638.0 kg
    const wasteRes = calculateGoodsAndWasteEmissions(200, 'Most', true);
    expect(wasteRes).toBeCloseTo(638.0, 1);
  });

  test('Full Integrated Calculator Summary', () => {
    const testInputs: EstimatorInputs = {
      carDistanceWeekly: 150,
      carFuelType: 'EV', // 150 * 52 * 0.05 = 390.0 kg
      publicTransitDistanceWeekly: 0,
      shortHaulFlightsYearly: 0,
      longHaulFlightsYearly: 0,
      electricityMonthlyKwh: 250, // 250 * 12 * 0.38 * (1 - 0.2) = 912.0 kg (20% green energy)
      greenEnergySharePct: 20,
      heatingFuelType: 'Electricity', // 100 * 12 * 0.13 = 156.0 kg
      heatingMonthlyKwh: 100,
      dietType: 'Low Meat', // 1500.0 kg
      localFoodSharePct: 100, // 10% reduction => 1350.0 kg
      monthlySpendingGoods: 50, // 50 * 12 * 0.12 = 72.0 kg
      recyclingLevel: 'All', // 30% reduction
      compostWaste: false, // 0% reduction (total waste = 500 * 0.7 = 350.0 kg)
    };
    
    const fullBreakdown = calculateTotalCarbonFootprint(testInputs);
    
    expect(fullBreakdown.transport).toBeCloseTo(390.0, 1);
    expect(fullBreakdown.energy).toBeCloseTo(1068.0, 1);
    expect(fullBreakdown.diet).toBeCloseTo(1350.0, 1);
    expect(fullBreakdown.waste).toBeCloseTo(422.0, 1);
    expect(fullBreakdown.total).toBeCloseTo(3230.0, 1);
  });

  test('Edge Case - All Inputs Zero', () => {
    const zeroInputs: EstimatorInputs = {
      carDistanceWeekly: 0,
      carFuelType: 'None',
      publicTransitDistanceWeekly: 0,
      shortHaulFlightsYearly: 0,
      longHaulFlightsYearly: 0,
      electricityMonthlyKwh: 0,
      greenEnergySharePct: 0,
      heatingFuelType: 'None',
      heatingMonthlyKwh: 0,
      dietType: 'Medium Meat', // base is 2000.0 kg
      localFoodSharePct: 0,
      monthlySpendingGoods: 0,
      recyclingLevel: 'None',
      compostWaste: false,
    };

    const breakdown = calculateTotalCarbonFootprint(zeroInputs);
    expect(breakdown.transport).toBe(0);
    expect(breakdown.energy).toBe(0);
    expect(breakdown.diet).toBe(2000.0);
    expect(breakdown.waste).toBe(500.0); // Baseline municipal waste
    expect(breakdown.total).toBe(2500.0);
  });

});
