import React from 'react';
import { EstimatorInputs, CarFuelType, HeatingFuelType, DietType, RecyclingLevel } from '../types';

interface EstimatorFormProps {
  inputs: EstimatorInputs;
  onChange: (inputs: EstimatorInputs) => void;
}

// Allowed enum values for verification/sanitization
const VALID_CAR_FUELS: CarFuelType[] = ['Petrol', 'Diesel', 'Hybrid', 'EV', 'None'];
const VALID_HEATING_FUELS: HeatingFuelType[] = ['Natural Gas', 'Heating Oil', 'Electricity', 'Biomass', 'None'];
const VALID_DIET_TYPES: DietType[] = ['High Meat', 'Medium Meat', 'Low Meat', 'Pescatarian', 'Vegetarian', 'Vegan'];
const VALID_RECYCLING_LEVELS: RecyclingLevel[] = ['None', 'Some', 'Most', 'All'];

export const EstimatorForm: React.FC<EstimatorFormProps> = ({ inputs, onChange }) => {
  
  // Strict numeric sanitization with capping
  const sanitizeNumber = (val: string, maxLimit: number = 100000): number => {
    if (val.trim().startsWith('-')) return 0;
    // Strip non-numeric and non-decimal characters
    const cleanStr = val.replace(/[^0-9.]/g, '');
    const parts = cleanStr.split('.');
    // Re-stitch to ensure at most one decimal point
    const singleDotStr = parts.length > 2 
      ? `${parts[0]}.${parts.slice(1).join('')}` 
      : cleanStr;
      
    const parsed = parseFloat(singleDotStr);
    if (isNaN(parsed) || parsed <= 0) return 0;
    return Math.min(parsed, maxLimit);
  };

  const handleNumericChange = (field: keyof EstimatorInputs, rawValue: string, maxLimit?: number) => {
    const sanitized = sanitizeNumber(rawValue, maxLimit);
    onChange({
      ...inputs,
      [field]: sanitized
    });
  };

  const handleCarFuelChange = (rawValue: string) => {
    const validated = VALID_CAR_FUELS.includes(rawValue as CarFuelType) 
      ? (rawValue as CarFuelType) 
      : 'None';
    onChange({ ...inputs, carFuelType: validated });
  };

  const handleHeatingFuelChange = (rawValue: string) => {
    const validated = VALID_HEATING_FUELS.includes(rawValue as HeatingFuelType) 
      ? (rawValue as HeatingFuelType) 
      : 'None';
    // If selecting none, also reset monthly heating usage to 0
    onChange({ 
      ...inputs, 
      heatingFuelType: validated,
      heatingMonthlyKwh: validated === 'None' ? 0 : inputs.heatingMonthlyKwh 
    });
  };

  const handleDietTypeChange = (rawValue: string) => {
    const validated = VALID_DIET_TYPES.includes(rawValue as DietType) 
      ? (rawValue as DietType) 
      : 'Medium Meat';
    onChange({ ...inputs, dietType: validated });
  };

  const handleRecyclingLevelChange = (rawValue: string) => {
    const validated = VALID_RECYCLING_LEVELS.includes(rawValue as RecyclingLevel) 
      ? (rawValue as RecyclingLevel) 
      : 'None';
    onChange({ ...inputs, recyclingLevel: validated });
  };

  const handleCheckboxChange = (field: keyof EstimatorInputs, checked: boolean) => {
    onChange({ ...inputs, [field]: checked });
  };

  // Modern accessible focus class with high contrast outline
  const inputClass = "w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded px-3 py-2 text-xs transition duration-150 focus:outline-none focus:ring-2 focus:ring-accent-green focus:border-transparent";
  const labelClass = "block text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider mb-1";
  const helperClass = "text-[9px] text-slate-400 dark:text-slate-500 block mt-1 leading-normal";
  const sectionTitleClass = "text-xs font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-1 mb-3";

  return (
    <section 
      className="glass-panel p-6 space-y-6 h-full overflow-y-auto"
      aria-labelledby="estimator-heading"
    >
      <div>
        <h2 id="estimator-heading" className="text-lg font-bold text-slate-900 dark:text-white">
          Footprint Estimator
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Fill out your daily details to calculate your carbon impact instantly.
        </p>
      </div>

      {/* 1. Transportation Section */}
      <fieldset className="space-y-4 border-none p-0 m-0">
        <legend className={`${sectionTitleClass} text-accent-green w-full`}>
          1. Transportation
        </legend>
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="carDistanceWeekly" className={labelClass}>
              Car Travel (km / week)
            </label>
            <input
              id="carDistanceWeekly"
              type="text"
              inputMode="decimal"
              pattern="[0-9]*\.?[0-9]*"
              placeholder="e.g. 100"
              value={inputs.carDistanceWeekly || ''}
              onChange={(e) => handleNumericChange('carDistanceWeekly', e.target.value, 10000)}
              aria-describedby="car-distance-help"
              className={inputClass}
            />
            <span id="car-distance-help" className={helperClass}>
              Include regular commutes and leisure trips.
            </span>
          </div>
          <div>
            <label htmlFor="carFuelType" className={labelClass}>
              Car Fuel Type
            </label>
            <select
              id="carFuelType"
              value={inputs.carFuelType}
              onChange={(e) => handleCarFuelChange(e.target.value)}
              aria-describedby="car-fuel-help"
              className={inputClass}
            >
              <option value="None">No Car / Do not drive</option>
              <option value="Petrol">Petrol (Gasoline)</option>
              <option value="Diesel">Diesel</option>
              <option value="Hybrid">Hybrid</option>
              <option value="EV">Electric Vehicle (EV)</option>
            </select>
            <span id="car-fuel-help" className={helperClass}>
              Used to calculate vehicle fuel efficiency.
            </span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label htmlFor="publicTransitDistance" className={labelClass}>
              Transit (km/wk)
            </label>
            <input
              id="publicTransitDistance"
              type="text"
              inputMode="decimal"
              pattern="[0-9]*\.?[0-9]*"
              placeholder="e.g. 30"
              value={inputs.publicTransitDistanceWeekly || ''}
              onChange={(e) => handleNumericChange('publicTransitDistanceWeekly', e.target.value, 10000)}
              aria-describedby="transit-help"
              className={inputClass}
            />
            <span id="transit-help" className={helperClass}>
              Bus, subway, train.
            </span>
          </div>
          <div>
            <label htmlFor="shortHaulFlights" className={labelClass}>
              Short Flights (/yr)
            </label>
            <input
              id="shortHaulFlights"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder="e.g. 2"
              value={inputs.shortHaulFlightsYearly || ''}
              onChange={(e) => handleNumericChange('shortHaulFlightsYearly', e.target.value, 365)}
              aria-describedby="short-flights-help"
              className={inputClass}
            />
            <span id="short-flights-help" className={helperClass}>
              &lt; 3 hours flights.
            </span>
          </div>
          <div>
            <label htmlFor="longHaulFlights" className={labelClass}>
              Long Flights (/yr)
            </label>
            <input
              id="longHaulFlights"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder="e.g. 1"
              value={inputs.longHaulFlightsYearly || ''}
              onChange={(e) => handleNumericChange('longHaulFlightsYearly', e.target.value, 365)}
              aria-describedby="long-flights-help"
              className={inputClass}
            />
            <span id="long-flights-help" className={helperClass}>
              &gt; 3 hours flights.
            </span>
          </div>
        </div>
      </fieldset>

      {/* 2. Home Energy Section */}
      <fieldset className="space-y-4 border-none p-0 m-0">
        <legend className={`${sectionTitleClass} text-amber-600 dark:text-amber-500 w-full`}>
          2. Home Energy
        </legend>
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="electricityMonthlyKwh" className={labelClass}>
              Electricity (kWh / month)
            </label>
            <input
              id="electricityMonthlyKwh"
              type="text"
              inputMode="decimal"
              pattern="[0-9]*\.?[0-9]*"
              placeholder="e.g. 300"
              value={inputs.electricityMonthlyKwh || ''}
              onChange={(e) => handleNumericChange('electricityMonthlyKwh', e.target.value, 50000)}
              aria-describedby="electricity-help"
              className={inputClass}
            />
            <span id="electricity-help" className={helperClass}>
              From your utility monthly bills.
            </span>
          </div>
          <div>
            <label htmlFor="greenEnergySharePct" className={labelClass}>
              Green Share (%)
            </label>
            <input
              id="greenEnergySharePct"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder="e.g. 100"
              value={inputs.greenEnergySharePct || ''}
              onChange={(e) => handleNumericChange('greenEnergySharePct', e.target.value, 100)}
              aria-describedby="green-share-help"
              className={inputClass}
            />
            <span id="green-share-help" className={helperClass}>
              Renewables percentage.
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="heatingFuelType" className={labelClass}>
              Heating Fuel
            </label>
            <select
              id="heatingFuelType"
              value={inputs.heatingFuelType}
              onChange={(e) => handleHeatingFuelChange(e.target.value)}
              aria-describedby="heating-fuel-help"
              className={inputClass}
            >
              <option value="None">None / Heat Free</option>
              <option value="Natural Gas">Natural Gas</option>
              <option value="Heating Oil">Heating Oil</option>
              <option value="Electricity">Electric Heat Pump</option>
              <option value="Biomass">Biomass (Wood Pellets)</option>
            </select>
            <span id="heating-fuel-help" className={helperClass}>
              Primary method of heating your home.
            </span>
          </div>
          <div>
            <label htmlFor="heatingMonthlyKwh" className={labelClass}>
              Heating Usage (kWh / month)
            </label>
            <input
              id="heatingMonthlyKwh"
              type="text"
              inputMode="decimal"
              pattern="[0-9]*\.?[0-9]*"
              placeholder="e.g. 400"
              value={inputs.heatingMonthlyKwh || ''}
              disabled={inputs.heatingFuelType === 'None'}
              onChange={(e) => handleNumericChange('heatingMonthlyKwh', e.target.value, 50000)}
              aria-describedby="heating-usage-help"
              className={`${inputClass} disabled:opacity-40 disabled:bg-slate-50 dark:disabled:bg-slate-950 disabled:cursor-not-allowed`}
            />
            <span id="heating-usage-help" className={helperClass}>
              Heating consumption.
            </span>
          </div>
        </div>
      </fieldset>

      {/* 3. Dietary Habits Section */}
      <fieldset className="space-y-4 border-none p-0 m-0">
        <legend className={`${sectionTitleClass} text-blue-600 dark:text-blue-500 w-full`}>
          3. Dietary Habits
        </legend>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="dietType" className={labelClass}>
              Primary Diet Profile
            </label>
            <select
              id="dietType"
              value={inputs.dietType}
              onChange={(e) => handleDietTypeChange(e.target.value)}
              aria-describedby="diet-help"
              className={inputClass}
            >
              <option value="High Meat">High Meat (Heavy daily meat)</option>
              <option value="Medium Meat">Average Meat (Regular intake)</option>
              <option value="Low Meat">Low Meat (Vegetarian-focused)</option>
              <option value="Pescatarian">Pescatarian (Fish & veggies)</option>
              <option value="Vegetarian">Vegetarian (No meat)</option>
              <option value="Vegan">Vegan (Purely plant-based)</option>
            </select>
            <span id="diet-help" className={helperClass}>
              Reflects agricultural emission footprints.
            </span>
          </div>
          <div>
            <div className="flex justify-between items-baseline mb-1">
              <label htmlFor="localFoodSharePct" className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">
                Local Food Sourcing
              </label>
              <span className="text-xs font-extrabold text-accent-green" aria-hidden="true">
                {inputs.localFoodSharePct}%
              </span>
            </div>
            <input
              id="localFoodSharePct"
              type="range"
              min="0"
              max="100"
              step="5"
              value={inputs.localFoodSharePct}
              onChange={(e) => handleNumericChange('localFoodSharePct', e.target.value, 100)}
              aria-valuenow={inputs.localFoodSharePct}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-describedby="local-food-help"
              className="w-full accent-accent-green bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full cursor-pointer focus:outline-none focus:ring-2 focus:ring-accent-green"
            />
            <span id="local-food-help" className={helperClass}>
              Proportion of groceries sourced locally (reduces food-miles).
            </span>
          </div>
        </div>
      </fieldset>

      {/* 4. Goods & Waste Section */}
      <fieldset className="space-y-4 border-none p-0 m-0">
        <legend className={`${sectionTitleClass} text-pink-600 dark:text-pink-500 w-full`}>
          4. Goods & Waste
        </legend>
        
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="monthlySpendingGoods" className={labelClass}>
              Goods Spending ($ / month)
            </label>
            <input
              id="monthlySpendingGoods"
              type="text"
              inputMode="decimal"
              pattern="[0-9]*\.?[0-9]*"
              placeholder="e.g. 100"
              value={inputs.monthlySpendingGoods || ''}
              onChange={(e) => handleNumericChange('monthlySpendingGoods', e.target.value, 100000)}
              aria-describedby="spending-help"
              className={inputClass}
            />
            <span id="spending-help" className={helperClass}>
              New clothes, gadgets, and items bought.
            </span>
          </div>
          <div>
            <label htmlFor="recyclingLevel" className={labelClass}>
              Household Recycling
            </label>
            <select
              id="recyclingLevel"
              value={inputs.recyclingLevel}
              onChange={(e) => handleRecyclingLevelChange(e.target.value)}
              aria-describedby="recycling-help"
              className={inputClass}
            >
              <option value="None">None (All to landfill)</option>
              <option value="Some">Some (Separate basic papers)</option>
              <option value="Most">Most (Separate plastic/metals/paper)</option>
              <option value="All">All (Zero-waste sorting)</option>
            </select>
            <span id="recycling-help" className={helperClass}>
              Level of municipal waste sorting.
            </span>
          </div>
        </div>

        <div className="flex items-start gap-3 pt-2">
          <input
            id="compostWaste"
            type="checkbox"
            checked={inputs.compostWaste}
            onChange={(e) => handleCheckboxChange('compostWaste', e.target.checked)}
            aria-describedby="compost-help"
            className="w-4 h-4 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-accent-green rounded focus:ring-2 focus:ring-accent-green accent-accent-green cursor-pointer mt-0.5"
          />
          <div className="flex-1">
            <label htmlFor="compostWaste" className="text-xs text-slate-800 dark:text-slate-200 font-bold cursor-pointer select-none">
              We compost organic food waste
            </label>
            <span id="compost-help" className={`${helperClass} -mt-0.5`}>
              Organic composting prevents heavy methane landfill emissions.
            </span>
          </div>
        </div>
      </fieldset>
    </section>
  );
};
export default EstimatorForm;
