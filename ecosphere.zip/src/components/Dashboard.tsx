import React, { useState } from 'react';
import { EmissionBreakdown } from '../types';
import { ShieldAlert, TrendingDown } from 'lucide-react';
import { EcosystemSimulation } from './EcosystemSimulation';

interface DashboardProps {
  baselineBreakdown: EmissionBreakdown;
  projectedBreakdown: EmissionBreakdown;
  onSaveToHistory: () => void;
  isSaving: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  baselineBreakdown, 
  projectedBreakdown, 
  onSaveToHistory, 
  isSaving 
}) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const totalTons = projectedBreakdown.total / 1000;
  const targetTons = 2.0;
  const globalAvgTons = 4.5;

  const isUnderTarget = totalTons <= targetTons;
  const percentDiff = ((totalTons - targetTons) / targetTons) * 100;

  const categories = [
    { name: 'Transport', value: projectedBreakdown.transport, color: '#059669', bg: 'bg-emerald-600' },
    { name: 'Home Energy', value: projectedBreakdown.energy, color: '#D97706', bg: 'bg-amber-600' },
    { name: 'Diet', value: projectedBreakdown.diet, color: '#2563EB', bg: 'bg-blue-600' },
    { name: 'Goods & Waste', value: projectedBreakdown.waste, color: '#DB2777', bg: 'bg-pink-650' },
  ];

  const totalValue = categories.reduce((sum, cat) => sum + cat.value, 0) || 1;

  const radius = 60;
  const strokeWidth = 12;
  const circumference = 2 * Math.PI * radius;
  let accumulatedPercentage = 0;

  return (
    <div className="space-y-6">
      
      {/* Accessible screen reader live region announcing changes */}
      <div 
        className="sr-only" 
        role="region" 
        aria-live="polite"
      >
        Your current annual projected carbon footprint is {totalTons.toFixed(2)} metric tons. 
        Sustainable target is {targetTons.toFixed(1)} metric tons.
        {isUnderTarget 
          ? "This is below the sustainable target limit." 
          : `This is ${percentDiff.toFixed(0)}% over the sustainable target limit.`
        }
      </div>

      {/* Top Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Footprint Indicator */}
        <section 
          className="glass-panel p-5 flex flex-col justify-between"
          aria-label="Annual footprint reading"
        >
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">
              Annual Footprint
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-4xl font-extrabold text-slate-900 dark:text-white">
                {totalTons.toFixed(2)}
              </span>
              <span className="text-xs font-bold text-accent-green">
                t CO2e / yr
              </span>
            </div>
          </div>
          
          <div className="mt-3">
            {isUnderTarget ? (
              <div className="inline-flex items-center gap-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold border border-emerald-250 dark:border-emerald-900/50">
                <TrendingDown className="w-3 h-3" />
                Below Sustainable Target
              </div>
            ) : (
              <div className="inline-flex items-center gap-1 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-450 px-2 py-0.5 rounded text-[10px] font-bold border border-rose-250 dark:border-rose-900/50">
                <ShieldAlert className="w-3 h-3" />
                {percentDiff.toFixed(0)}% Over Sustainable Target
              </div>
            )}
          </div>
        </section>

        {/* Benchmarks Progress */}
        <section 
          className="glass-panel p-5 space-y-3 justify-center flex flex-col"
          aria-label="Carbon target comparison metrics"
        >
          <div className="space-y-2">
            {/* Target 2.0 t */}
            <div>
              <div className="flex justify-between text-[10px] font-medium text-slate-500 dark:text-slate-450 mb-0.5">
                <span>Sustainable Target Limit</span>
                <span className="text-accent-green font-bold">{targetTons.toFixed(1)} t</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${isUnderTarget ? 'bg-accent-green' : 'bg-accent-green/45'}`} 
                  style={{ width: `${Math.min(100, (totalTons / targetTons) * 100)}%` }}
                />
              </div>
            </div>

            {/* Global average */}
            <div>
              <div className="flex justify-between text-[10px] font-medium text-slate-500 dark:text-slate-450 mb-0.5">
                <span>Global Average Baseline</span>
                <span className="text-amber-600 dark:text-amber-450 font-bold">{globalAvgTons.toFixed(1)} t</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-600 dark:bg-amber-500 rounded-full transition-all duration-500" 
                  style={{ width: `${Math.min(100, (totalTons / globalAvgTons) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </section>

      </div>

      {/* Visual Chart & Table columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* SVG Donut Component */}
        <section 
          className="glass-panel p-5 flex flex-col items-center justify-center min-h-[220px] lg:col-span-5"
          aria-label="Emissions distribution donut chart"
        >
          <div className="relative w-40 h-40">
            <svg 
              className="w-full h-full transform -rotate-90" 
              viewBox="0 0 160 160"
            >
              <title>Carbon Output Distribution</title>
              <circle 
                cx="80" 
                cy="80" 
                r={radius} 
                className="stroke-slate-100 dark:stroke-slate-800 fill-none" 
                strokeWidth={strokeWidth} 
              />
              {categories.map((cat, idx) => {
                const percentage = cat.value / totalValue;
                const strokeDash = percentage * circumference;
                const strokeOffset = circumference - (accumulatedPercentage / 100) * circumference;
                
                accumulatedPercentage += percentage * 100;
                const isHovered = hoveredIndex === idx;
                const pctLabel = (percentage * 100).toFixed(0);

                return (
                  <circle
                    key={cat.name}
                    cx="80"
                    cy="80"
                    r={radius}
                    tabIndex={0}
                    role="img"
                    aria-label={`${cat.name} slice representing ${pctLabel}% of your carbon footprint`}
                    className="fill-none cursor-pointer transition-all duration-200 focus:outline-none focus:stroke-slate-900 dark:focus:stroke-white"
                    stroke={cat.color}
                    strokeWidth={isHovered ? strokeWidth + 2.5 : strokeWidth}
                    strokeDasharray={`${strokeDash} ${circumference}`}
                    strokeDashoffset={strokeOffset}
                    strokeLinecap="round"
                    onMouseEnter={() => setHoveredIndex(idx)}
                    onMouseLeave={() => setHoveredIndex(null)}
                    onFocus={() => setHoveredIndex(idx)}
                    onBlur={() => setHoveredIndex(null)}
                  />
                );
              })}
            </svg>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
              <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide">
                {hoveredIndex !== null ? categories[hoveredIndex].name : 'Total Impact'}
              </span>
              <span className="text-xl font-extrabold text-slate-900 dark:text-white">
                {hoveredIndex !== null 
                  ? `${(categories[hoveredIndex].value / 1000).toFixed(2)}t` 
                  : `${totalTons.toFixed(2)}t`
                }
              </span>
            </div>
          </div>
        </section>

        {/* Data Table & Action Commit */}
        <section 
          className="glass-panel p-5 space-y-3 flex flex-col justify-between lg:col-span-7"
          aria-label="Category metrics ledger detail"
        >
          <div className="space-y-3 flex-1 flex flex-col justify-center">
            {categories.map((cat, idx) => {
              const pct = (cat.value / totalValue) * 100;
              const isHovered = hoveredIndex === idx;

              return (
                <div 
                  key={cat.name} 
                  className={`transition rounded p-1.5 ${isHovered ? 'bg-slate-50 dark:bg-slate-800/40' : ''}`}
                  onMouseEnter={() => setHoveredIndex(idx)}
                  onMouseLeave={() => setHoveredIndex(null)}
                >
                  <div className="flex justify-between text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-0.5">
                    <span className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${cat.bg}`} />
                      {cat.name}
                    </span>
                    <span className="text-slate-900 dark:text-white font-bold">
                      {(cat.value / 1000).toFixed(2)} t ({pct.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="h-1 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${cat.bg}`} 
                      style={{ width: `${pct}%` }} 
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={onSaveToHistory}
              disabled={isSaving || projectedBreakdown.total === 0}
              className="glow-btn px-4 py-2 w-full text-xs font-bold text-white bg-accent-green hover:bg-accent-green-hover disabled:opacity-40 disabled:cursor-not-allowed rounded transition cursor-pointer focus:outline-none focus:ring-2 focus:ring-accent-green focus:ring-offset-1"
            >
              {isSaving ? 'Saving Log...' : 'Commit to History Ledger'}
            </button>
          </div>
        </section>

      </div>

      {/* Physics Simulation Section */}
      <EcosystemSimulation 
        breakdown={baselineBreakdown} 
        projectedBreakdown={projectedBreakdown} 
      />

    </div>
  );
};
export default Dashboard;
