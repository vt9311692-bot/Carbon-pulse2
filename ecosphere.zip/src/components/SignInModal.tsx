import React, { useState, useEffect, useRef } from 'react';
import { X, Lock, Mail, Eye, EyeOff } from 'lucide-react';

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: { email: string; token: string }) => void;
}

export const SignInModal: React.FC<SignInModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [isRegister, setIsRegister] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  const modalRef = useRef<HTMLDivElement>(null);

  // Focus trapping and escape listener for WCAG 2.1 accessibility compliance
  useEffect(() => {
    if (!isOpen) return;
    
    // Clear states when opening
    setEmail('');
    setPassword('');
    setErrorMsg('');
    setIsRegister(false);
    
    // Set initial focus to email input
    const initialFocus = document.getElementById('auth-email');
    if (initialFocus) {
      setTimeout(() => initialFocus.focus(), 50);
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
        return;
      }
      
      if (e.key === 'Tab' && modalRef.current) {
        const focusableElements = modalRef.current.querySelectorAll(
          'input:not([disabled]), button:not([disabled]), [tabindex="0"]'
        );
        if (focusableElements.length === 0) return;
        
        const first = focusableElements[0] as HTMLElement;
        const last = focusableElements[focusableElements.length - 1] as HTMLElement;
        
        if (e.shiftKey) { // Shift + Tab
          if (document.activeElement === first) {
            last.focus();
            e.preventDefault();
          }
        } else { // Tab
          if (document.activeElement === last) {
            first.focus();
            e.preventDefault();
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Strict sanitization rules
  const cleanEmail = (val: string): string => {
    return val.replace(/[<>'"\\;]/g, '').trim(); // strip SQL/HTML tokens
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const sanitizedEmail = cleanEmail(email);
    if (!sanitizedEmail || !sanitizedEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    setIsLoading(true);
    const endpoint = isRegister ? '/api/register' : '/api/login';

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: sanitizedEmail, password }),
      });

      const data = await response.json();
      if (response.ok && data.token) {
        onSuccess({ email: data.email, token: data.token });
        onClose();
      } else {
        setErrorMsg(data.message || 'Authentication failed. Please verify credentials.');
      }
    } catch (err) {
      console.error('Authentication request error:', err);
      setErrorMsg('Unable to connect to authentication server.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      aria-describedby="auth-modal-desc"
    >
      <div 
        ref={modalRef}
        className="glass-panel w-full max-w-sm p-6 relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl rounded-xl"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition focus:outline-none focus:ring-2 focus:ring-accent-green"
          aria-label="Close dialog modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-1 mb-6">
          <div className="w-10 h-10 rounded bg-accent-green/10 flex items-center justify-center text-accent-green border border-accent-green/20 mx-auto mb-2">
            <Lock className="w-5 h-5" />
          </div>
          <h2 
            id="auth-modal-title" 
            className="text-md font-extrabold text-slate-900 dark:text-white uppercase tracking-wider"
          >
            {isRegister ? 'Create Account' : 'Sign In to Pulse'}
          </h2>
          <p 
            id="auth-modal-desc" 
            className="text-[10px] text-slate-500 dark:text-slate-400"
          >
            {isRegister 
              ? 'Register to sync your footprint metrics to the ledger.' 
              : 'Log in to access your saved calculation dashboard profiles.'
            }
          </p>
        </div>

        {/* Error Message Announcement */}
        {errorMsg && (
          <div 
            className="mb-4 p-2.5 bg-rose-50 dark:bg-rose-950/40 text-[10px] font-bold text-rose-700 dark:text-rose-450 border border-rose-250 dark:border-rose-900/50 rounded"
            role="alert"
            aria-live="polite"
          >
            {errorMsg}
          </div>
        )}

        {/* Auth Form */}
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label 
              htmlFor="auth-email" 
              className="block text-[9px] font-bold text-slate-500 dark:text-slate-450 uppercase tracking-wider mb-1"
            >
              Email Address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 pointer-events-none">
                <Mail className="w-3.5 h-3.5" />
              </span>
              <input
                id="auth-email"
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded text-xs focus:outline-none focus:ring-2 focus:ring-accent-green focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label 
              htmlFor="auth-password" 
              className="block text-[9px] font-bold text-slate-500 dark:text-slate-450 uppercase tracking-wider mb-1"
            >
              Password
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 pointer-events-none">
                <Lock className="w-3.5 h-3.5" />
              </span>
              <input
                id="auth-password"
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-10 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded text-xs focus:outline-none focus:ring-2 focus:ring-accent-green focus:border-transparent"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 transition focus:outline-none focus:ring-2 focus:ring-accent-green rounded-full p-0.5"
                aria-label={showPassword ? "Hide password text" : "Show password text"}
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2 bg-accent-green hover:bg-accent-green-hover text-white rounded text-xs font-bold transition flex items-center justify-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-accent-green disabled:opacity-40 disabled:cursor-not-allowed shadow"
          >
            {isLoading ? 'Processing Authentications...' : isRegister ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        {/* Footer Link Options */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800/80 text-center text-[10px] text-slate-500">
          {isRegister ? (
            <span>
              Already have an account?{' '}
              <button
                onClick={() => { setIsRegister(false); setErrorMsg(''); }}
                className="text-accent-green font-bold hover:underline focus:outline-none focus:ring-2 focus:ring-accent-green px-1 rounded"
              >
                Sign In
              </button>
            </span>
          ) : (
            <span>
              Don't have an account?{' '}
              <button
                onClick={() => { setIsRegister(true); setErrorMsg(''); }}
                className="text-accent-green font-bold hover:underline focus:outline-none focus:ring-2 focus:ring-accent-green px-1 rounded"
              >
                Sign Up
              </button>
            </span>
          )}
        </div>

      </div>
    </div>
  );
};
export default SignInModal;
