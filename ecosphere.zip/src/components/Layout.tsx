import React, { useState, useEffect } from 'react';
import { EstimatorForm } from './EstimatorForm';
import { Dashboard } from './Dashboard';
import { AIInsights } from './AIInsights';
import { HistoryLedger } from './HistoryLedger';
import { SignInModal } from './SignInModal';
import { EstimatorInputs, HistoryEntry } from '../types';
import { calculateTotalCarbonFootprint, getDefaultInputs } from '../utils/emissionFactors';
import { generateRecommendations } from '../utils/mockData';
import { encryptData, decryptData } from '../utils/crypto';
import { Leaf, LayoutDashboard, History, Sun, Moon, Lock, User } from 'lucide-react';

export const Layout: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history'>(() => {
    const saved = localStorage.getItem('activeTab');
    return (saved === 'dashboard' || saved === 'history') ? saved : 'dashboard';
  });
  
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('theme');
    return (saved === 'light' || saved === 'dark') ? saved : 'light';
  });

  const [inputs, setInputs] = useState<EstimatorInputs>(getDefaultInputs());
  const [user, setUser] = useState<{ email: string; token: string } | null>(null);
  const [isStateLoaded, setIsStateLoaded] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  
  const [adoptedIds, setAdoptedIds] = useState<string[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Sync theme
  useEffect(() => {
    localStorage.setItem('theme', theme);
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Sync active tab
  useEffect(() => {
    localStorage.setItem('activeTab', activeTab);
  }, [activeTab]);

  // 1. Asynchronously load and decrypt secure localStorage state on mount
  useEffect(() => {
    const loadState = async () => {
      // Decrypt inputs
      const encryptedInputs = localStorage.getItem('estimatorInputs_secure');
      if (encryptedInputs) {
        try {
          const decrypted = await decryptData(encryptedInputs);
          const parsed = JSON.parse(decrypted);
          setInputs(parsed);
        } catch (e) {
          console.error('Failed to decrypt and load secured inputs state:', e);
          setInputs(getDefaultInputs());
        }
      } else {
        const legacy = localStorage.getItem('estimatorInputs');
        if (legacy) {
          try {
            const parsed = JSON.parse(legacy);
            setInputs(parsed);
            const encrypted = await encryptData(legacy);
            localStorage.setItem('estimatorInputs_secure', encrypted);
            localStorage.removeItem('estimatorInputs');
          } catch (err) {
            console.error('Failed parsing legacy state:', err);
          }
        }
      }

      // Decrypt user profile
      const encryptedUser = localStorage.getItem('user_secure');
      if (encryptedUser) {
        try {
          const decUser = await decryptData(encryptedUser);
          setUser(JSON.parse(decUser));
        } catch (err) {
          console.error('Failed to decrypt secure user state:', err);
        }
      }

      setIsStateLoaded(true);
    };

    loadState();
  }, []);

  // 2. Asynchronously encrypt and save state changes when inputs/user change
  useEffect(() => {
    if (!isStateLoaded) return;

    const saveState = async () => {
      try {
        const payload = JSON.stringify(inputs);
        const encrypted = await encryptData(payload);
        localStorage.setItem('estimatorInputs_secure', encrypted);
      } catch (e) {
        console.error('Failed to securely encrypt and save inputs changes:', e);
      }
    };

    saveState();
  }, [inputs, isStateLoaded]);

  useEffect(() => {
    if (!isStateLoaded) return;

    const saveUserState = async () => {
      try {
        if (user) {
          const enc = await encryptData(JSON.stringify(user));
          localStorage.setItem('user_secure', enc);
        } else {
          localStorage.removeItem('user_secure');
        }
      } catch (e) {
        console.error('Failed to securely save user auth state:', e);
      }
    };

    saveUserState();
  }, [user, isStateLoaded]);

  // Fetch calculations logs list from API
  const fetchHistory = async () => {
    setIsHistoryLoading(true);
    try {
      const headers: Record<string, string> = {};
      if (user && user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      }
      
      const res = await fetch('/api/history', { headers });
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch (e) {
      console.error('Failed to fetch history logs:', e);
    } finally {
      setIsHistoryLoading(false);
    }
  };

  // Re-fetch calculations list whenever user logs in or out
  useEffect(() => {
    if (isStateLoaded) {
      fetchHistory();
    }
  }, [user, isStateLoaded]);

  const handleInputChange = (newInputs: EstimatorInputs) => {
    setInputs(newInputs);
    setAdoptedIds([]); // Reset offsets when baseline changes
  };

  // Memoize emissions calculations for real-time reactivity
  const breakdown = React.useMemo(() => {
    return calculateTotalCarbonFootprint(inputs);
  }, [inputs]);

  // Memoize recommendation suggestions matching current inputs
  const recommendations = React.useMemo(() => {
    return generateRecommendations(inputs);
  }, [inputs]);

  // Toggle adopted recommendation items to simulate offsets
  const handleToggleAdopt = (id: string) => {
    setAdoptedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // Calculate projected emissions (active breakdown minus simulated savings)
  const projectedBreakdown = React.useMemo(() => {
    const savings = recommendations
      .filter(rec => adoptedIds.includes(rec.id))
      .reduce((sum, rec) => {
        sum[rec.category] = (sum[rec.category] || 0) + rec.savingValue;
        sum.total += rec.savingValue;
        return sum;
      }, { transport: 0, energy: 0, diet: 0, waste: 0, total: 0 });

    return {
      transport: Math.max(0, breakdown.transport - savings.transport),
      energy: Math.max(0, breakdown.energy - savings.energy),
      diet: Math.max(0, breakdown.diet - savings.diet),
      waste: Math.max(0, breakdown.waste - savings.waste),
      total: Math.max(0, breakdown.total - savings.total),
    };
  }, [breakdown, recommendations, adoptedIds]);

  const handleSaveToHistory = async () => {
    setIsSaving(true);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user && user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      }

      const response = await fetch('/api/history', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          transport: projectedBreakdown.transport,
          energy: projectedBreakdown.energy,
          diet: projectedBreakdown.diet,
          waste: projectedBreakdown.waste,
          total: projectedBreakdown.total,
        }),
      });
      if (response.ok) {
        await fetchHistory();
        setActiveTab('history');
      }
    } catch (e) {
      console.error('Failed to commit log to history:', e);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteEntry = async (id: number) => {
    try {
      const headers: Record<string, string> = {};
      if (user && user.token) {
        headers['Authorization'] = `Bearer ${user.token}`;
      }

      const response = await fetch(`/api/history?id=${id}`, {
        method: 'DELETE',
        headers
      });
      if (response.ok) {
        fetchHistory();
      }
    } catch (e) {
      console.error('Failed to delete history log:', e);
    }
  };

  if (!isStateLoaded) {
    return (
      <div className="min-h-screen bg-bg-light dark:bg-slate-950 flex flex-col items-center justify-center font-sans text-slate-800 dark:text-slate-100">
        <div className="text-center space-y-3">
          <Lock className="w-8 h-8 mx-auto text-accent-green animate-pulse" />
          <p className="text-xs font-bold uppercase tracking-wider">Decrypting Secure Local State...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-light text-text-dark flex flex-col font-sans transition-colors duration-200">
      
      {/* Skip to Content navigation link for WCAG compliance */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:bg-accent-green focus:text-white focus:px-4 focus:py-2 focus:rounded focus:font-bold focus:z-50 focus:outline-none focus:ring-2 focus:ring-white"
      >
        Skip to main content
      </a>

      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-bg-card/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-bg-card-border dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-accent-green/10 flex items-center justify-center text-accent-green border border-accent-green/20">
              <Leaf className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-sm text-text-dark dark:text-white uppercase tracking-wider">
              CarbonPulse
            </span>
          </div>

          {/* Navigation Controls */}
          <nav className="flex items-center gap-1.5" aria-label="Main Navigation">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-bg-card-hover dark:bg-slate-800 text-text-dark dark:text-white font-bold'
                  : 'text-text-dim hover:text-text-dark dark:hover:text-white'
              } focus:outline-none focus:ring-2 focus:ring-accent-green`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              Dashboard
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-bg-card-hover dark:bg-slate-800 text-text-dark dark:text-white font-bold'
                  : 'text-text-dim hover:text-text-dark dark:hover:text-white'
              } focus:outline-none focus:ring-2 focus:ring-accent-green`}
            >
              <History className="w-3.5 h-3.5" />
              Ledger
            </button>

            {/* Dark/Light Theme Toggler */}
            <button
              onClick={() => setTheme(prev => prev === 'light' ? 'dark' : 'light')}
              className="p-1.5 rounded text-text-dim hover:text-text-dark dark:hover:text-white transition cursor-pointer ml-1 bg-bg-card-hover/40 dark:bg-slate-800/40 border border-bg-card-border/50 dark:border-slate-800/50 focus:outline-none focus:ring-2 focus:ring-accent-green animate-fade-in"
              aria-label="Toggle dark mode theme"
            >
              {theme === 'light' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
            </button>

            {/* User Session Controller */}
            {user ? (
              <div className="flex items-center gap-1.5 ml-2 border-l border-bg-card-border dark:border-slate-800 pl-3">
                <div className="hidden md:flex items-center gap-1 text-[10px] font-semibold text-slate-500 max-w-[120px] truncate" title={user.email}>
                  <User className="w-3 h-3 text-accent-green shrink-0" />
                  {user.email.split('@')[0]}
                </div>
                <button
                  onClick={() => {
                    setUser(null);
                    setHistory([]);
                  }}
                  className="px-2.5 py-1 rounded border border-rose-200 dark:border-rose-900/40 text-[9px] font-bold uppercase tracking-wider text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 transition cursor-pointer focus:outline-none focus:ring-2 focus:ring-rose-500"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="ml-2 flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-accent-green hover:bg-accent-green-hover text-white transition cursor-pointer focus:outline-none focus:ring-2 focus:ring-accent-green shadow"
              >
                Sign In
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* Split Dashboard Content */}
      <main 
        id="main-content"
        className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6"
      >
        
        {/* Left Side: Real-time inputs */}
        <div className="lg:col-span-5 h-auto lg:h-[calc(100vh-140px)] static lg:sticky lg:top-20">
          <EstimatorForm inputs={inputs} onChange={handleInputChange} />
        </div>

        {/* Right Side: Visualizations and Ledger */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Guest Mode Banner */}
          {!user && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 text-[10px] text-amber-800 dark:text-amber-400 rounded-lg border border-amber-250 dark:border-amber-900/30 flex items-center justify-between shadow-sm">
              <span>
                <strong>Guest Mode:</strong> Calculations are saved locally. <button onClick={() => setIsAuthModalOpen(true)} className="font-bold underline text-amber-900 dark:text-amber-200 hover:text-accent-green focus:outline-none focus:ring-1 focus:ring-accent-green rounded px-0.5">Sign In</button> to sync footprints to your persistent cloud ledger.
              </span>
            </div>
          )}

          {activeTab === 'dashboard' ? (
            <>
              <Dashboard 
                baselineBreakdown={breakdown}
                projectedBreakdown={projectedBreakdown} 
                onSaveToHistory={handleSaveToHistory} 
                isSaving={isSaving} 
              />
              
              <AIInsights 
                recommendations={recommendations} 
                adoptedIds={adoptedIds} 
                onToggleAdopt={handleToggleAdopt} 
              />
            </>
          ) : (
            <HistoryLedger 
              history={history} 
              onDeleteEntry={handleDeleteEntry} 
              isLoading={isHistoryLoading} 
            />
          )}
        </div>

      </main>

      <footer className="py-4 border-t border-bg-card-border dark:border-slate-850 bg-bg-card dark:bg-slate-900 text-center text-[9px] text-text-dim dark:text-slate-500">
        CarbonPulse Platform &copy; 2026. Designed for speed, precision, and low-latency client performance.
      </footer>

      {/* Sign In & Registration Modal */}
      <SignInModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onSuccess={(u) => setUser(u)} 
      />

    </div>
  );
};
export default Layout;
