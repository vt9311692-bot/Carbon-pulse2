import React from 'react';
import { HistoryEntry } from '../types';
import { Trash, Calendar } from 'lucide-react';

interface HistoryLedgerProps {
  history: HistoryEntry[];
  onDeleteEntry: (id: number) => void;
  isLoading: boolean;
}

export const HistoryLedger: React.FC<HistoryLedgerProps> = ({
  history,
  onDeleteEntry,
  isLoading,
}) => {
  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString(undefined, { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    } catch {
      return dateStr;
    }
  };

  const sparklinePoints = React.useMemo(() => {
    if (history.length < 2) return '';
    
    const sorted = [...history].sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const width = 500;
    const height = 80;
    const padding = 10;
    
    const minTime = new Date(sorted[0].timestamp).getTime();
    const maxTime = new Date(sorted[sorted.length - 1].timestamp).getTime();
    const timeRange = maxTime - minTime || 1;

    const totals = sorted.map(e => e.total / 1000);
    const maxVal = Math.max(...totals, 4.0);
    const minVal = Math.min(...totals, 0);
    const valRange = maxVal - minVal || 1;

    return sorted.map((entry) => {
      const time = new Date(entry.timestamp).getTime();
      const x = padding + ((time - minTime) / timeRange) * (width - 2 * padding);
      const y = height - padding - ((entry.total / 1000 - minVal) / valRange) * (height - 2 * padding);
      return `${x},${y}`;
    }).join(' ');
  }, [history]);

  const sparklineTargetY = React.useMemo(() => {
    if (history.length < 2) return 0;
    const sorted = [...history].sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    const height = 80;
    const padding = 10;
    const totals = sorted.map(e => e.total / 1000);
    const maxVal = Math.max(...totals, 4.0);
    const minVal = Math.min(...totals, 0);
    const valRange = maxVal - minVal || 1;

    return height - padding - ((2.0 - minVal) / valRange) * (height - 2 * padding);
  }, [history]);

  return (
    <div className="space-y-4">
      {/* Sparkline */}
      {history.length >= 2 && (
        <div className="glass-panel p-4 space-y-2">
          <div className="flex items-center justify-between text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
            <span>Emission Trend Progression</span>
            <div className="flex gap-2">
              <span className="flex items-center gap-1"><span className="w-1.5 h-0.5 bg-emerald-600" /> Progression</span>
              <span className="flex items-center gap-1"><span className="w-1.5 h-0.5 bg-rose-500/60" /> Target (2.0t)</span>
            </div>
          </div>

          <div className="relative w-full h-[80px] bg-slate-50 rounded border border-slate-200 p-1">
            <svg viewBox="0 0 500 80" className="w-full h-full" preserveAspectRatio="none">
              <line x1="10" y1={sparklineTargetY} x2="490" y2={sparklineTargetY} stroke="#EF4444" strokeWidth="1" strokeDasharray="3 3" opacity="0.5" />
              <polyline
                fill="none"
                stroke="#059669"
                strokeWidth="2.5"
                points={sparklinePoints}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>
      )}

      {/* Table Ledger */}
      <div className="glass-panel p-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Calculations Ledger</span>
          <span className="text-[9px] text-slate-400">{history.length} saved entries</span>
        </div>

        {isLoading ? (
          <div className="py-8 text-center text-slate-400 text-xs">Fetching records...</div>
        ) : history.length === 0 ? (
          <div className="py-8 text-center text-slate-400 space-y-1.5">
            <Calendar className="w-5 h-5 mx-auto opacity-30" />
            <p className="text-xs font-semibold text-slate-500">Ledger is empty</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px] border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-2 px-3">Date</th>
                  <th className="py-2 px-3">Transport</th>
                  <th className="py-2 px-3">Energy</th>
                  <th className="py-2 px-3">Diet</th>
                  <th className="py-2 px-3">Waste</th>
                  <th className="py-2 px-3">Total</th>
                  <th className="py-2 px-3 text-right">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-650">
                {[...history].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map(entry => {
                  const isSustain = entry.total / 1000 <= 2.0;

                  return (
                    <tr key={entry.id} className="hover:bg-slate-50 transition">
                      <td className="py-2 px-3 font-semibold text-slate-800">{formatDate(entry.timestamp)}</td>
                      <td className="py-2 px-3">{(entry.transport / 1000).toFixed(2)} t</td>
                      <td className="py-2 px-3">{(entry.energy / 1000).toFixed(2)} t</td>
                      <td className="py-2 px-3">{(entry.diet / 1000).toFixed(2)} t</td>
                      <td className="py-2 px-3">{(entry.waste / 1000).toFixed(2)} t</td>
                      <td className="py-2 px-3">
                        <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] border ${
                          isSustain 
                            ? 'bg-emerald-50 border-emerald-100 text-emerald-700' 
                            : 'bg-rose-50 border-rose-100 text-rose-700'
                        }`}>
                          {(entry.total / 1000).toFixed(2)} t
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right">
                        <button
                          onClick={() => onDeleteEntry(entry.id)}
                          className="p-1 rounded text-slate-400 hover:text-rose-600 transition cursor-pointer"
                        >
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
