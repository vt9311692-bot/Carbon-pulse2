import React, { useRef, useEffect, useState } from 'react';
import { EmissionBreakdown } from '../types';
import { RotateCcw, ArrowUp, Info } from 'lucide-react';

interface EcosystemSimulationProps {
  breakdown: EmissionBreakdown;          // Baseline emissions (heavy blocks)
  projectedBreakdown: EmissionBreakdown; // Emissions after offsets (anti-gravity applied)
}

interface PhysicsBlock {
  id: string;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  mass: number; // in tons
  color: string;
  textColor: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  color: string;
}



export const EcosystemSimulation: React.FC<EcosystemSimulationProps> = ({
  breakdown,
  projectedBreakdown
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [selectedBlockId, setSelectedBlockId] = useState<string>('transport');
  const [simulationStatus, setSimulationStatus] = useState<string>('Ecosystem balanced.');
  const [showInfo, setShowInfo] = useState<boolean>(false);

  // Keep track of physics states in refs to avoid re-triggering React state changes on every physics frame
  const blocksRef = useRef<PhysicsBlock[]>([
    { id: 'transport', name: 'Transport', x: 50, y: 50, vx: 0, vy: 0, width: 40, height: 40, mass: 1, color: '#059669', textColor: '#ffffff' },
    { id: 'energy', name: 'Energy', x: 130, y: 50, vx: 0, vy: 0, width: 40, height: 40, mass: 1, color: '#D97706', textColor: '#ffffff' },
    { id: 'diet', name: 'Diet', x: 210, y: 50, vx: 0, vy: 0, width: 40, height: 40, mass: 1, color: '#2563EB', textColor: '#ffffff' },
    { id: 'waste', name: 'Waste', x: 290, y: 50, vx: 0, vy: 0, width: 40, height: 40, mass: 1, color: '#DB2777', textColor: '#ffffff' }
  ]);

  const particlesRef = useRef<Particle[]>([]);

  const mouseRef = useRef<{ x: number; y: number; isDown: boolean; dragBlock: PhysicsBlock | null }>({
    x: 0,
    y: 0,
    isDown: false,
    dragBlock: null
  });

  // Calculate and sync block sizes based on baseline emissions
  useEffect(() => {
    blocksRef.current = blocksRef.current.map(block => {
      let baseVal = 0;
      switch (block.id) {
        case 'transport': baseVal = breakdown.transport; break;
        case 'energy':    baseVal = breakdown.energy; break;
        case 'diet':      baseVal = breakdown.diet; break;
        case 'waste':     baseVal = breakdown.waste; break;
      }
      
      const mass = baseVal / 1000; // convert to tons
      // Clamp dimensions between 35px and 85px for UI scale consistency
      const size = Math.max(35, Math.min(85, 35 + mass * 12));
      return {
        ...block,
        mass: Math.max(0.1, mass),
        width: size,
        height: size
      };
    });
  }, [breakdown]);

  // Handle anti-gravity live region announcements
  useEffect(() => {
    const activeOffsets: string[] = [];
    const categories: ('transport' | 'energy' | 'diet' | 'waste')[] = ['transport', 'energy', 'diet', 'waste'];
    
    categories.forEach(cat => {
      const saving = breakdown[cat] - projectedBreakdown[cat];
      if (saving > 0) {
        activeOffsets.push(`${cat} (${(saving / 1000).toFixed(2)} t)`);
      }
    });

    if (activeOffsets.length > 0) {
      setSimulationStatus(`Anti-gravity vector active: ${activeOffsets.join(', ')} are floating.`);
    } else {
      setSimulationStatus('Carbon gravity pulling blocks down. Log green offsets to trigger anti-gravity.');
    }
  }, [breakdown, projectedBreakdown]);

  // Run Canvas Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = canvas.width;
    let height = canvas.height;

    // Handle high DPI display scaling
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
      width = rect.width;
      height = rect.height;
    };

    resizeCanvas();
    const resizeObserver = new ResizeObserver(() => {
      resizeCanvas();
    });
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const restitution = 0.25; // bounciness
    const gravity = 0.18;      // gravity coefficient

    const tick = () => {
      ctx.clearRect(0, 0, width, height);

      // 1. Draw Background Sky/Eco gradient
      const isDark = document.documentElement.classList.contains('dark');
      const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
      if (isDark) {
        skyGrad.addColorStop(0, '#090D10');
        skyGrad.addColorStop(1, '#111823');
      } else {
        skyGrad.addColorStop(0, '#F8FAFC');
        skyGrad.addColorStop(1, '#EEF2F6');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, width, height);

      // Draw dashed threshold representing target level limit (2.0t)
      ctx.strokeStyle = isDark ? 'rgba(239, 68, 68, 0.25)' : 'rgba(239, 68, 68, 0.35)';
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(10, height - 70);
      ctx.lineTo(width - 10, height - 70);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = isDark ? '#EF4444' : '#DC2626';
      ctx.font = 'bold 8px Outfit, sans-serif';
      ctx.fillText('Sustainable Target Limit (2.0t)', 15, height - 74);

      // Draw grass ecosystem floor
      ctx.fillStyle = isDark ? '#065F46' : '#A7F3D0';
      ctx.fillRect(0, height - 35, width, 35);
      ctx.fillStyle = isDark ? '#047857' : '#34D399';
      ctx.fillRect(0, height - 35, width, 2);

      // 2. Physics logic and Drawing
      const blocks = blocksRef.current;

      // Handle drag constraint
      const mouse = mouseRef.current;
      if (mouse.isDown && mouse.dragBlock) {
        const drag = mouse.dragBlock;
        drag.x = Math.max(0, Math.min(width - drag.width, mouse.x - drag.width / 2));
        drag.y = Math.max(0, Math.min(height - drag.height, mouse.y - drag.height / 2));
        drag.vx = 0;
        drag.vy = 0;
      }

      blocks.forEach(block => {
        // Calculate lift force based on savings
        let baseline = 0;
        let net = 0;
        switch (block.id) {
          case 'transport':
            baseline = breakdown.transport;
            net = projectedBreakdown.transport;
            break;
          case 'energy':
            baseline = breakdown.energy;
            net = projectedBreakdown.energy;
            break;
          case 'diet':
            baseline = breakdown.diet;
            net = projectedBreakdown.diet;
            break;
          case 'waste':
            baseline = breakdown.waste;
            net = projectedBreakdown.waste;
            break;
        }

        const savings = baseline - net;
        const netMass = net / 1000;
        
        // Anti-gravity vector calculation
        // As green offsets increase, an upward lift force is applied
        const lift = (savings / 1000) * 0.22; 
        
        if (block !== mouse.dragBlock) {
          // Apply gravity
          block.vy += gravity * block.mass;
          
          // Apply anti-gravity lift
          if (lift > 0) {
            block.vy -= lift;
            
            // Spawn continuous green anti-gravity exhaust thrust particles
            if (Math.random() < 0.25) {
              particlesRef.current.push({
                x: block.x + block.width / 2 + (Math.random() * 20 - 10),
                y: block.y + block.height,
                vx: (Math.random() * 2 - 1) * 0.5,
                vy: Math.random() * 1.5 + 1.0,
                radius: Math.random() * 3 + 1,
                alpha: 1.0,
                color: '#34D399'
              });
            }

            // Draw balloon strings to leaf balloons
            const balloonX = block.x + block.width / 2;
            const balloonY = block.y - 35;
            ctx.strokeStyle = isDark ? 'rgba(52, 211, 153, 0.4)' : 'rgba(5, 150, 105, 0.5)';
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(balloonX, block.y);
            ctx.quadraticCurveTo(balloonX + Math.sin(Date.now() / 200) * 5, block.y - 18, balloonX, balloonY);
            ctx.stroke();

            // Render balloon leaf
            ctx.fillStyle = '#34D399';
            ctx.beginPath();
            ctx.ellipse(balloonX, balloonY, 8, 12, 0, 0, Math.PI * 2);
            ctx.fill();
            // Balloon accent
            ctx.fillStyle = '#059669';
            ctx.beginPath();
            ctx.ellipse(balloonX - 2, balloonY - 4, 2, 4, 0.2, 0, Math.PI * 2);
            ctx.fill();
          }

          // Apply velocity and drag
          block.vy *= 0.98;
          block.vx *= 0.98;
          block.y += block.vy;
          block.x += block.vx;

          // Wall Collision left/right
          if (block.x < 5) {
            block.x = 5;
            block.vx = -block.vx * restitution;
          } else if (block.x + block.width > width - 5) {
            block.x = width - block.width - 5;
            block.vx = -block.vx * restitution;
          }

          // Floor boundary collision
          const groundLevel = height - 35 - block.height;
          if (block.y > groundLevel) {
            block.y = groundLevel;
            block.vy = -block.vy * restitution;
            block.vx *= 0.85; // grass friction
          }
          // Ceiling boundary collision
          if (block.y < 5) {
            block.y = 5;
            block.vy = -block.vy * restitution;
          }
        }

        // Render block shadow/glow
        ctx.save();
        ctx.shadowColor = block.color;
        ctx.shadowBlur = selectedBlockId === block.id ? 10 : 3;
        
        // Draw Rounded Rectangle for heavy block
        ctx.fillStyle = block.color;
        const r = 6; // border-radius
        const bx = block.x, by = block.y, bw = block.width, bh = block.height;
        ctx.beginPath();
        ctx.moveTo(bx + r, by);
        ctx.lineTo(bx + bw - r, by);
        ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + r);
        ctx.lineTo(bx + bw, by + bh - r);
        ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - r, by + bh);
        ctx.lineTo(bx + r, by + bh);
        ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - r);
        ctx.lineTo(bx, by + r);
        ctx.quadraticCurveTo(bx, by, bx + r, by);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        // Focus outline for selected block
        if (selectedBlockId === block.id) {
          ctx.strokeStyle = isDark ? '#FFFFFF' : '#000000';
          ctx.lineWidth = 2;
          ctx.stroke();
        }

        // Draw Text inside blocks
        ctx.fillStyle = block.textColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = 'bold 8px Outfit, sans-serif';
        // Label
        ctx.fillText(block.name, block.x + block.width / 2, block.y + block.height / 2 - 5);
        // Metric Weight (tons)
        ctx.font = 'Outfit, sans-serif 8px';
        ctx.fillText(`${netMass.toFixed(2)}t`, block.x + block.width / 2, block.y + block.height / 2 + 5);
      });

      // 3. Resolve AABB collisions between blocks (pile them up)
      for (let i = 0; i < blocks.length; i++) {
        for (let j = i + 1; j < blocks.length; j++) {
          const b1 = blocks[i];
          const b2 = blocks[j];
          
          if (b1.x < b2.x + b2.width && b1.x + b1.width > b2.x &&
              b1.y < b2.y + b2.height && b1.y + b1.height > b2.y) {
            
            const overlapX = Math.min(b1.x + b1.width - b2.x, b2.x + b2.width - b1.x);
            const overlapY = Math.min(b1.y + b1.height - b2.y, b2.y + b2.height - b1.y);

            if (overlapX < overlapY) {
              const pushX = overlapX / 2;
              if (b1.x + b1.width / 2 < b2.x + b2.width / 2) {
                b1.x -= pushX;
                b2.x += pushX;
              } else {
                b1.x += pushX;
                b2.x -= pushX;
              }
              const temp = b1.vx;
              b1.vx = b2.vx * 0.4;
              b2.vx = temp * 0.4;
            } else {
              const pushY = overlapY / 2;
              if (b1.y + b1.height / 2 < b2.y + b2.height / 2) {
                b1.y -= pushY;
                b2.y += pushY;
              } else {
                b1.y += pushY;
                b2.y -= pushY;
              }
              const temp = b1.vy;
              b1.vy = b2.vy * 0.4;
              b2.vy = temp * 0.4;
            }
          }
        }
      }

      // 4. Update and Render Particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.02;
        if (p.alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animationId = requestAnimationFrame(tick);
    };

    tick();

    return () => {
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();
    };
  }, [breakdown, projectedBreakdown, selectedBlockId]);

  // Pointer interaction
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Find if a block was clicked
    const blocks = blocksRef.current;
    let clickedBlock: PhysicsBlock | null = null;
    for (let i = blocks.length - 1; i >= 0; i--) {
      const b = blocks[i];
      if (x >= b.x && x <= b.x + b.width && y >= b.y && y <= b.y + b.height) {
        clickedBlock = b;
        break;
      }
    }

    if (clickedBlock) {
      setSelectedBlockId(clickedBlock.id);
      mouseRef.current = {
        x,
        y,
        isDown: true,
        dragBlock: clickedBlock
      };
      canvas.setPointerCapture(e.pointerId);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    mouseRef.current.x = x;
    mouseRef.current.y = y;
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    mouseRef.current.isDown = false;
    mouseRef.current.dragBlock = null;
    canvas.releasePointerCapture(e.pointerId);
  };

  // Keyboard controls
  const handleReset = () => {
    const width = canvasRef.current?.width ? canvasRef.current.width / (window.devicePixelRatio || 1) : 400;
    blocksRef.current.forEach((block, idx) => {
      block.x = 40 + idx * 85;
      block.y = 30;
      block.vx = 0;
      block.vy = 0;
    });
    // Spawn dust explosion particles
    for (let i = 0; i < 20; i++) {
      particlesRef.current.push({
        x: Math.random() * width,
        y: 100,
        vx: (Math.random() * 4 - 2),
        vy: (Math.random() * 4 - 2),
        radius: Math.random() * 4 + 1.5,
        alpha: 1.0,
        color: '#10B981'
      });
    }
  };

  const applyUpwardBoost = () => {
    const block = blocksRef.current.find(b => b.id === selectedBlockId);
    if (block) {
      block.vy = -7.5; // push up
      // Add heavy particle thruster blast
      for (let i = 0; i < 15; i++) {
        particlesRef.current.push({
          x: block.x + block.width / 2 + (Math.random() * 16 - 8),
          y: block.y + block.height,
          vx: (Math.random() * 3 - 1.5),
          vy: Math.random() * 4 + 3,
          radius: Math.random() * 3.5 + 1.5,
          alpha: 1.0,
          color: block.color
        });
      }
      setSimulationStatus(`Applied upward vector push to ${block.name} block.`);
    }
  };

  const applyLateralPush = (dir: 'left' | 'right') => {
    const block = blocksRef.current.find(b => b.id === selectedBlockId);
    if (block) {
      block.vx = dir === 'left' ? -4 : 4;
      setSimulationStatus(`Pushed ${block.name} block to the ${dir}.`);
    }
  };

  return (
    <article className="glass-panel p-5 space-y-4">
      
      {/* Header Controls */}
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
            Ecosystem Balance Simulation
            <button 
              onClick={() => setShowInfo(!showInfo)} 
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition p-0.5 focus:outline-none focus:ring-2 focus:ring-accent-green rounded-full"
              aria-label="Show simulation instructions"
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </h3>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
            Interact with your carbon weight blocks. Active offsets act as anti-gravity vector balloons.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800 rounded bg-white dark:bg-slate-900 hover:shadow-sm transition flex items-center gap-1 text-[10px] font-bold focus:outline-none focus:ring-2 focus:ring-accent-green"
          aria-label="Reset all simulation blocks to sky"
        >
          <RotateCcw className="w-3 h-3" />
          Reset Blocks
        </button>
      </div>

      {showInfo && (
        <div className="bg-slate-50 dark:bg-slate-950 p-2.5 rounded text-[10px] text-slate-650 dark:text-slate-400 border border-slate-200 dark:border-slate-800 space-y-1">
          <p className="font-bold text-slate-800 dark:text-slate-200">How to Interact:</p>
          <ul className="list-disc pl-4 space-y-0.5">
            <li><strong>Mouse/Touch:</strong> Click and drag blocks to throw them around.</li>
            <li><strong>Balloons:</strong> Adopting reductions attaches green balloons that lift blocks.</li>
            <li><strong>Keyboard Navigation:</strong> Use the select buttons below, then use Boost / Left / Right arrows to apply physics impulses.</li>
          </ul>
        </div>
      )}

      {/* ARIA Live Region for screen reader updates */}
      <div 
        className="sr-only" 
        role="status" 
        aria-live="polite"
      >
        {simulationStatus}
      </div>

      {/* Canvas container and Screen-Reader accessible inner DOM content */}
      <div 
        ref={containerRef}
        className="relative w-full h-[180px] bg-slate-50 dark:bg-slate-950 rounded border border-slate-200 dark:border-slate-800 overflow-hidden"
      >
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="w-full h-full cursor-grab active:cursor-grabbing block"
          style={{ touchAction: 'none' }}
          role="application"
          aria-label="2D Carbon Ecosystem Simulation. Shows Transport, Energy, Diet and Waste blocks."
        >
          {/* Accessible fallback markup inside canvas */}
          <div className="sr-only">
            <p>Carbon footprint blocks simulation state:</p>
            <ul>
              {blocksRef.current.map(b => (
                <li key={b.id}>
                  {b.name} block: Mass {b.mass.toFixed(2)} tons.
                </li>
              ))}
            </ul>
          </div>
        </canvas>
      </div>

      {/* Simulation Controls - Full Keyboard Tab Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 items-center bg-slate-50 dark:bg-slate-900/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
        
        {/* Block Selector */}
        <div className="flex flex-col gap-1">
          <label htmlFor="active-block-select" className="text-[9px] uppercase tracking-wider font-bold text-slate-500">
            Selected Keyboard Focus Block:
          </label>
          <div className="flex flex-wrap gap-1">
            {blocksRef.current.map(b => (
              <button
                key={b.id}
                onClick={() => setSelectedBlockId(b.id)}
                className={`px-2 py-1 text-[10px] font-bold rounded border transition ${
                  selectedBlockId === b.id
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-transparent shadow'
                    : 'bg-white dark:bg-slate-800 text-slate-650 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                } focus:outline-none focus:ring-2 focus:ring-accent-green`}
              >
                {b.name}
              </button>
            ))}
          </div>
        </div>

        {/* Impulse Action Buttons */}
        <div className="flex flex-col gap-1">
          <span className="text-[9px] uppercase tracking-wider font-bold text-slate-500">
            Apply Physics Vector Force:
          </span>
          <div className="flex gap-1">
            <button
              onClick={() => applyLateralPush('left')}
              className="px-2.5 py-1 text-[10px] font-bold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded hover:bg-slate-50 text-slate-700 dark:text-slate-350 focus:outline-none focus:ring-2 focus:ring-accent-green flex-1"
              aria-label={`Push selected block left`}
            >
              Push Left
            </button>
            <button
              onClick={applyUpwardBoost}
              className="px-2.5 py-1 text-[10px] font-bold bg-accent-green text-white rounded hover:bg-accent-green-hover shadow-sm transition flex items-center justify-center gap-1 focus:outline-none focus:ring-2 focus:ring-accent-green flex-1"
              aria-label={`Apply upward boost lift to selected block`}
            >
              <ArrowUp className="w-3 h-3 stroke-[2.5]" />
              Lift Boost
            </button>
            <button
              onClick={() => applyLateralPush('right')}
              className="px-2.5 py-1 text-[10px] font-bold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded hover:bg-slate-50 text-slate-700 dark:text-slate-350 focus:outline-none focus:ring-2 focus:ring-accent-green flex-1"
              aria-label={`Push selected block right`}
            >
              Push Right
            </button>
          </div>
        </div>

      </div>

    </article>
  );
};
export default EcosystemSimulation;
