import React, { useMemo } from 'react';
import { RecommendationAction } from '../types';
import * as Icons from 'lucide-react';

interface AIInsightsProps {
  recommendations: RecommendationAction[];
  adoptedIds: string[];
  onToggleAdopt: (id: string) => void;
}

const DynamicIcon = ({ name, className }: { name: string; className?: string }) => {
  const IconComponent = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[name];
  if (!IconComponent) return <Icons.Sparkles className={className} />;
  return <IconComponent className={className} />;
};

export const AIInsights: React.FC<AIInsightsProps> = ({
  recommendations,
  adoptedIds,
  onToggleAdopt,
}) => {
  const totalSavings = useMemo(() => {
    return recommendations
      .filter(rec => adoptedIds.includes(rec.id))
      .reduce((sum, rec) => sum + rec.savingValue, 0);
  }, [recommendations, adoptedIds]);

  return (
    <div className="glass-panel p-5 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Actionable Recommendations</h3>
          <p className="text-[10px] text-slate-500 mt-0.5">Toggle suggestions to simulate your potential emission savings.</p>
        </div>
        
        {totalSavings > 0 && (
          <div className="text-right">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Simulated Savings</span>
            <span className="text-xs font-extrabold text-emerald-600">
              -{(totalSavings / 1000).toFixed(2)} t CO2e / yr
            </span>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {recommendations.slice(0, 4).map(rec => {
          const isAdopted = adoptedIds.includes(rec.id);

          return (
            <div 
              key={rec.id}
              onClick={() => onToggleAdopt(rec.id)}
              className={`flex items-start justify-between p-2.5 rounded border transition-all cursor-pointer select-none ${
                isAdopted 
                  ? 'border-emerald-500/20 bg-emerald-50/50 shadow-sm' 
                  : 'border-slate-200 bg-white hover:bg-slate-50'
              }`}
            >
              <div className="flex gap-2.5 items-start">
                <span className="p-1 rounded bg-slate-100 text-slate-500 mt-0.5">
                  <DynamicIcon name={rec.icon} className="w-3.5 h-3.5" />
                </span>
                <div>
                  <h4 className="text-xs font-bold text-slate-800">{rec.title}</h4>
                  <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">{rec.description}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 ml-4">
                <span className="text-[10px] font-bold text-emerald-600 whitespace-nowrap">
                  -{rec.savingValue} kg
                </span>
                <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center transition-all ${
                  isAdopted 
                    ? 'border-emerald-600 bg-emerald-600 text-white' 
                    : 'border-slate-300 bg-white'
                }`}>
                  {isAdopted && <Icons.Check className="w-2.5 h-2.5 stroke-[3]" />}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
