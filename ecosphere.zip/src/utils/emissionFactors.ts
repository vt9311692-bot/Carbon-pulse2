/**
 * Emission Conversion Constants
 * Hardcoded based on standard EPA and Greenhouse Gas (GHG) Protocol guidelines.
 * Values represent kg CO2e per unit of consumption.
 */
export const EMISSION_FACTORS = {
  // Transport: kg CO2e per km
  transport: {
    carPetrol: 0.170,   // average petrol passenger vehicle
    carDiesel: 0.171,   // average diesel passenger vehicle
    carHybrid: 0.100,   // hybrid vehicle
    carEV: 0.050,       // electric vehicle (assumes average grid energy)
    publicTransit: 0.030, // average bus / light rail
    shortHaulFlight: 150.0, // kg CO2e per passenger per flight (< 1500 km / < 3 hours)
    longHaulFlight: 800.0,  // kg CO2e per passenger per flight (>= 1500 km / >= 3 hours)
  },

  // Home Energy: kg CO2e per kWh
  energy: {
    electricityGrid: 0.380, // average utility grid intensity
    heatingGas: 0.200,      // natural gas heating
    heatingOil: 0.270,      // heating oil
    heatingElectricity: 0.130, // heat pump / electric (high efficiency)
    heatingBiomass: 0.020,     // wood pellets / biomass
  },

  // Diet: Base annual emissions in kg CO2e per year
  diet: {
    highMeat: 2500.0,    // daily high meat consumption (>100g/day)
    mediumMeat: 2000.0,  // average meat consumption (50-100g/day)
    lowMeat: 1500.0,     // low meat consumption (<50g/day)
    pescatarian: 1300.0, // fish eaters
    vegetarian: 1100.0,  // no meat, yes dairy/eggs
    vegan: 700.0,        // plant-based only
  },

  // Goods & Waste: kg CO2e per unit
  goodsAndWaste: {
    spendingPerDollar: 0.120, // kg CO2e per dollar spent on new clothes, electronics, etc.
    wasteBaseAnnual: 500.0,   // baseline municipal waste per capita emissions (kg CO2e)
    compostingReduction: 0.10, // 10% reduction if composting
    recyclingReduction: {
      none: 0.0,
      some: 0.10, // 10% reduction
      most: 0.20, // 20% reduction
      all: 0.30,  // 30% reduction
    }
  }
} as const;

export type CarFuelType = 'Petrol' | 'Diesel' | 'Hybrid' | 'EV' | 'None';
export type HeatingFuelType = 'Natural Gas' | 'Heating Oil' | 'Electricity' | 'Biomass' | 'None';
export type DietType = 'High Meat' | 'Medium Meat' | 'Low Meat' | 'Pescatarian' | 'Vegetarian' | 'Vegan';
export type RecyclingLevel = 'None' | 'Some' | 'Most' | 'All';

export interface EstimatorInputs {
  // Transport
  carDistanceWeekly: number;
  carFuelType: CarFuelType;
  publicTransitDistanceWeekly: number;
  shortHaulFlightsYearly: number;
  longHaulFlightsYearly: number;

  // Home Energy
  electricityMonthlyKwh: number;
  greenEnergySharePct: number;
  heatingFuelType: HeatingFuelType;
  heatingMonthlyKwh: number;

  // Diet
  dietType: DietType;
  localFoodSharePct: number;

  // Goods & Waste
  monthlySpendingGoods: number;
  recyclingLevel: RecyclingLevel;
  compostWaste: boolean;
}

export interface EmissionBreakdown {
  transport: number; // kg CO2e
  energy: number;    // kg CO2e
  diet: number;      // kg CO2e
  waste: number;      // kg CO2e
  total: number;      // kg CO2e
}

/**
 * Calculates emissions for Transport category (in kg CO2e per year)
 */
export function calculateTransportEmissions(
  carDistanceWeekly: number,
  carFuelType: CarFuelType,
  publicTransitDistanceWeekly: number,
  shortHaulFlightsYearly: number,
  longHaulFlightsYearly: number
): number {
  const weeksPerYear = 52;
  let carFactor = 0;
  switch (carFuelType) {
    case 'Petrol': carFactor = EMISSION_FACTORS.transport.carPetrol; break;
    case 'Diesel': carFactor = EMISSION_FACTORS.transport.carDiesel; break;
    case 'Hybrid': carFactor = EMISSION_FACTORS.transport.carHybrid; break;
    case 'EV':     carFactor = EMISSION_FACTORS.transport.carEV; break;
    default:       carFactor = 0;
  }

  const carEmissions = carDistanceWeekly * weeksPerYear * carFactor;
  const transitEmissions = publicTransitDistanceWeekly * weeksPerYear * EMISSION_FACTORS.transport.publicTransit;
  const shortFlightEmissions = shortHaulFlightsYearly * EMISSION_FACTORS.transport.shortHaulFlight;
  const longFlightEmissions = longHaulFlightsYearly * EMISSION_FACTORS.transport.longHaulFlight;

  return Math.round((carEmissions + transitEmissions + shortFlightEmissions + longFlightEmissions) * 100) / 100;
}

/**
 * Calculates emissions for Home Energy category (in kg CO2e per year)
 */
export function calculateEnergyEmissions(
  electricityMonthlyKwh: number,
  greenEnergySharePct: number,
  heatingFuelType: HeatingFuelType,
  heatingMonthlyKwh: number
): number {
  const monthsPerYear = 12;
  const gridFactor = EMISSION_FACTORS.energy.electricityGrid;
  const netGridMultiplier = 1 - Math.min(100, Math.max(0, greenEnergySharePct)) / 100;
  
  const electricityEmissions = (electricityMonthlyKwh * monthsPerYear) * gridFactor * netGridMultiplier;

  let heatingFactor = 0;
  switch (heatingFuelType) {
    case 'Natural Gas':  heatingFactor = EMISSION_FACTORS.energy.heatingGas; break;
    case 'Heating Oil':  heatingFactor = EMISSION_FACTORS.energy.heatingOil; break;
    case 'Electricity':  heatingFactor = EMISSION_FACTORS.energy.heatingElectricity; break;
    case 'Biomass':      heatingFactor = EMISSION_FACTORS.energy.heatingBiomass; break;
    default:             heatingFactor = 0;
  }

  const heatingEmissions = (heatingMonthlyKwh * monthsPerYear) * heatingFactor;

  return Math.round((electricityEmissions + heatingEmissions) * 100) / 100;
}

/**
 * Calculates emissions for Diet category (in kg CO2e per year)
 */
export function calculateDietEmissions(
  dietType: DietType,
  localFoodSharePct: number
): number {
  let baseEmissions = 0;
  switch (dietType) {
    case 'High Meat':   baseEmissions = EMISSION_FACTORS.diet.highMeat; break;
    case 'Medium Meat': baseEmissions = EMISSION_FACTORS.diet.mediumMeat; break;
    case 'Low Meat':    baseEmissions = EMISSION_FACTORS.diet.lowMeat; break;
    case 'Pescatarian': baseEmissions = EMISSION_FACTORS.diet.pescatarian; break;
    case 'Vegetarian':  baseEmissions = EMISSION_FACTORS.diet.vegetarian; break;
    case 'Vegan':       baseEmissions = EMISSION_FACTORS.diet.vegan; break;
    default:            baseEmissions = EMISSION_FACTORS.diet.mediumMeat;
  }

  // Up to 10% reduction for 100% local/seasonal food
  const localReductionMultiplier = 1 - (Math.min(100, Math.max(0, localFoodSharePct)) / 100) * 0.10;
  
  return Math.round(baseEmissions * localReductionMultiplier * 100) / 100;
}

/**
 * Calculates emissions for Goods & Waste category (in kg CO2e per year)
 */
export function calculateGoodsAndWasteEmissions(
  monthlySpendingGoods: number,
  recyclingLevel: RecyclingLevel,
  compostWaste: boolean
): number {
  const monthsPerYear = 12;
  const spendingEmissions = (monthlySpendingGoods * monthsPerYear) * EMISSION_FACTORS.goodsAndWaste.spendingPerDollar;

  const baseWaste = EMISSION_FACTORS.goodsAndWaste.wasteBaseAnnual;
  
  let recyclingFactor = 0;
  switch (recyclingLevel) {
    case 'Some': recyclingFactor = EMISSION_FACTORS.goodsAndWaste.recyclingReduction.some; break;
    case 'Most': recyclingFactor = EMISSION_FACTORS.goodsAndWaste.recyclingReduction.most; break;
    case 'All':  recyclingFactor = EMISSION_FACTORS.goodsAndWaste.recyclingReduction.all; break;
    default:     recyclingFactor = EMISSION_FACTORS.goodsAndWaste.recyclingReduction.none;
  }

  const compostingFactor = compostWaste ? EMISSION_FACTORS.goodsAndWaste.compostingReduction : 0;
  
  // Apply waste reductions
  const wasteEmissions = baseWaste * (1 - recyclingFactor - compostingFactor);

  return Math.round((spendingEmissions + wasteEmissions) * 100) / 100;
}

/**
 * Main calculator summarizing all categories
 */
export function calculateTotalCarbonFootprint(inputs: EstimatorInputs): EmissionBreakdown {
  const transport = calculateTransportEmissions(
    inputs.carDistanceWeekly,
    inputs.carFuelType,
    inputs.publicTransitDistanceWeekly,
    inputs.shortHaulFlightsYearly,
    inputs.longHaulFlightsYearly
  );

  const energy = calculateEnergyEmissions(
    inputs.electricityMonthlyKwh,
    inputs.greenEnergySharePct,
    inputs.heatingFuelType,
    inputs.heatingMonthlyKwh
  );

  const diet = calculateDietEmissions(
    inputs.dietType,
    inputs.localFoodSharePct
  );

  const waste = calculateGoodsAndWasteEmissions(
    inputs.monthlySpendingGoods,
    inputs.recyclingLevel,
    inputs.compostWaste
  );

  const total = Math.round((transport + energy + diet + waste) * 100) / 100;

  return {
    transport,
    energy,
    diet,
    waste,
    total
  };
}

/**
 * Returns default/fallback inputs for empty/fresh forms
 */
export function getDefaultInputs(): EstimatorInputs {
  return {
    carDistanceWeekly: 0,
    carFuelType: 'None',
    publicTransitDistanceWeekly: 0,
    shortHaulFlightsYearly: 0,
    longHaulFlightsYearly: 0,
    electricityMonthlyKwh: 0,
    greenEnergySharePct: 0,
    heatingFuelType: 'None',
    heatingMonthlyKwh: 0,
    dietType: 'Medium Meat',
    localFoodSharePct: 0,
    monthlySpendingGoods: 0,
    recyclingLevel: 'None',
    compostWaste: false,
  };
}
