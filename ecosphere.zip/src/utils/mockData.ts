import { EstimatorInputs, RecommendationAction } from '../types';
import { EMISSION_FACTORS } from './emissionFactors';

/**
 * Dynamically generates personalized recommendations based on user inputs.
 */
export function generateRecommendations(inputs: EstimatorInputs): RecommendationAction[] {
  const recommendations: RecommendationAction[] = [];
  const weeksPerYear = 52;
  const monthsPerYear = 12;

  // 1. Transport Recommendations
  if (inputs.carFuelType === 'Petrol' || inputs.carFuelType === 'Diesel') {
    const fuelFactor = inputs.carFuelType === 'Petrol' 
      ? EMISSION_FACTORS.transport.carPetrol 
      : EMISSION_FACTORS.transport.carDiesel;
    
    // EV Switch
    const evSaving = Math.round(inputs.carDistanceWeekly * weeksPerYear * (fuelFactor - EMISSION_FACTORS.transport.carEV));
    if (evSaving > 200) {
      recommendations.push({
        id: 'switch_to_ev',
        category: 'transport',
        title: 'Switch to an Electric Vehicle (EV)',
        description: `Replace your ${inputs.carFuelType.toLowerCase()} vehicle with an EV. Assumes standard power grid intensity.`,
        savingValue: evSaving,
        icon: 'Zap',
        adopted: false,
      });
    }

    // Public Transit Transit
    const transitSaving = Math.round(inputs.carDistanceWeekly * 0.5 * weeksPerYear * (fuelFactor - EMISSION_FACTORS.transport.publicTransit));
    if (transitSaving > 100) {
      recommendations.push({
        id: 'commute_by_transit',
        category: 'transport',
        title: 'Opt for Public Transit',
        description: 'Shift 50% of your weekly car commute to public transportation (bus, rail, or subway).',
        savingValue: transitSaving,
        icon: 'Train',
        adopted: false,
      });
    }
  }

  if (inputs.shortHaulFlightsYearly > 0 || inputs.longHaulFlightsYearly > 0) {
    const flightSavings = Math.round(
      (inputs.shortHaulFlightsYearly * EMISSION_FACTORS.transport.shortHaulFlight * 0.5) +
      (inputs.longHaulFlightsYearly * EMISSION_FACTORS.transport.longHaulFlight * 0.25)
    );
    if (flightSavings > 50) {
      recommendations.push({
        id: 'reduce_flights',
        category: 'transport',
        title: 'Reduce and Offset Air Travel',
        description: 'Avoid 50% of short-haul flights by using high-speed rail, and reduce long-haul flights by 25%.',
        savingValue: flightSavings,
        icon: 'Plane',
        adopted: false,
      });
    }
  }

  // 2. Home Energy Recommendations
  if (inputs.greenEnergySharePct < 100 && inputs.electricityMonthlyKwh > 50) {
    const currentElectricityEmissions = (inputs.electricityMonthlyKwh * monthsPerYear) * 
      EMISSION_FACTORS.energy.electricityGrid * 
      (1 - inputs.greenEnergySharePct / 100);
    
    const greenTariffSaving = Math.round(currentElectricityEmissions);
    if (greenTariffSaving > 100) {
      recommendations.push({
        id: 'green_electricity',
        category: 'energy',
        title: 'Switch to a 100% Green Energy Tariff',
        description: 'Request a renewable energy plan from your utility provider or purchase local solar credits.',
        savingValue: greenTariffSaving,
        icon: 'Sun',
        adopted: false,
      });
    }
  }

  if (inputs.heatingFuelType === 'Natural Gas' || inputs.heatingFuelType === 'Heating Oil') {
    const currentFactor = inputs.heatingFuelType === 'Natural Gas' 
      ? EMISSION_FACTORS.energy.heatingGas 
      : EMISSION_FACTORS.energy.heatingOil;
    
    const heatPumpSaving = Math.round(
      (inputs.heatingMonthlyKwh * monthsPerYear) * (currentFactor - EMISSION_FACTORS.energy.heatingElectricity)
    );

    if (heatPumpSaving > 200) {
      recommendations.push({
        id: 'install_heat_pump',
        category: 'energy',
        title: 'Upgrade to a High-Efficiency Heat Pump',
        description: 'Replace fossil-fuel furnaces (gas/oil) with an energy-efficient electric heat pump.',
        savingValue: heatPumpSaving,
        icon: 'Wind',
        adopted: false,
      });
    }
  }

  // 3. Diet Recommendations
  if (inputs.dietType === 'High Meat' || inputs.dietType === 'Medium Meat') {
    const targetBase = inputs.dietType === 'High Meat' 
      ? EMISSION_FACTORS.diet.highMeat 
      : EMISSION_FACTORS.diet.mediumMeat;
    
    // Switch to Vegetarian
    const vegSaving = Math.round(targetBase - EMISSION_FACTORS.diet.vegetarian);
    recommendations.push({
      id: 'transition_vegetarian',
      category: 'diet',
      title: 'Transition to a Vegetarian Diet',
      description: 'Replace red meat and poultry with dairy, eggs, and rich plant-based protein sources.',
      savingValue: vegSaving,
      icon: 'Salad',
      adopted: false,
    });

    // Meatless Mondays
    const mondaySaving = Math.round((targetBase - EMISSION_FACTORS.diet.vegetarian) * (1 / 7));
    recommendations.push({
      id: 'meatless_mondays',
      category: 'diet',
      title: 'Adopt Meatless Mondays',
      description: 'Eat entirely vegetarian or vegan just one day per week to start your dietary transition.',
      savingValue: mondaySaving,
      icon: 'Calendar',
      adopted: false,
    });
  } else if (inputs.dietType === 'Vegetarian') {
    const veganSaving = Math.round(EMISSION_FACTORS.diet.vegetarian - EMISSION_FACTORS.diet.vegan);
    recommendations.push({
      id: 'transition_vegan',
      category: 'diet',
      title: 'Transition to a 100% Plant-based/Vegan Diet',
      description: 'Eliminate eggs, dairy, and animal-derived ingredients for a fully plant-based footprint.',
      savingValue: veganSaving,
      icon: 'Flower',
      adopted: false,
    });
  }

  if (inputs.localFoodSharePct < 80) {
    const baseDiet = EMISSION_FACTORS.diet[
      inputs.dietType === 'High Meat' ? 'highMeat' :
      inputs.dietType === 'Medium Meat' ? 'mediumMeat' :
      inputs.dietType === 'Low Meat' ? 'lowMeat' :
      inputs.dietType === 'Pescatarian' ? 'pescatarian' :
      inputs.dietType === 'Vegetarian' ? 'vegetarian' : 'vegan'
    ];
    
    const increaseLocalSaving = Math.round(baseDiet * 0.08); // roughly 8% potential reduction
    recommendations.push({
      id: 'buy_local_food',
      category: 'diet',
      title: 'Buy Local and Seasonal Produce',
      description: 'Prioritize regional farming, CSA boxes, and farmers markets to reduce food transport miles.',
      savingValue: increaseLocalSaving,
      icon: 'ShoppingBag',
      adopted: false,
    });
  }

  // 4. Waste & Goods Recommendations
  if (!inputs.compostWaste) {
    const compostSaving = Math.round(EMISSION_FACTORS.goodsAndWaste.wasteBaseAnnual * EMISSION_FACTORS.goodsAndWaste.compostingReduction);
    recommendations.push({
      id: 'compost_waste',
      category: 'waste',
      title: 'Start Composting Organic Waste',
      description: 'Divert food scraps, eggshells, and yard waste from landfills. Prevents methane generation.',
      savingValue: compostSaving,
      icon: 'Leaf',
      adopted: false,
    });
  }

  if (inputs.recyclingLevel === 'None' || inputs.recyclingLevel === 'Some') {
    const targetReduction = inputs.recyclingLevel === 'None' ? 0.20 : 0.10; // increase to 'Most'
    const recyclingSaving = Math.round(EMISSION_FACTORS.goodsAndWaste.wasteBaseAnnual * targetReduction);
    recommendations.push({
      id: 'maximize_recycling',
      category: 'waste',
      title: 'Improve Home Recycling Habits',
      description: 'Strictly separate paper, glass, aluminum, and plastics to divert waste from landfills.',
      savingValue: recyclingSaving,
      icon: 'RefreshCw',
      adopted: false,
    });
  }

  if (inputs.monthlySpendingGoods > 100) {
    const secondhandSaving = Math.round((inputs.monthlySpendingGoods * monthsPerYear * 0.3) * EMISSION_FACTORS.goodsAndWaste.spendingPerDollar);
    recommendations.push({
      id: 'buy_secondhand',
      category: 'waste',
      title: 'Buy Secondhand or Upcycle',
      description: 'Purchase 30% of your clothing, books, furniture, and electronics from pre-owned markets.',
      savingValue: secondhandSaving,
      icon: 'Tag',
      adopted: false,
    });
  }

  // Ensure we always have at least 2 default recommendations even for perfect users
  if (recommendations.length < 2) {
    recommendations.push({
      id: 'led_lighting',
      category: 'energy',
      title: 'Upgrade to Smart LED Lighting',
      description: 'Replace standard incandescent bulbs with energy-saving smart LED fixtures.',
      savingValue: 45,
      icon: 'Lightbulb',
      adopted: false,
    }, {
      id: 'unplug_phantom',
      category: 'energy',
      title: 'Eliminate Phantom Power Outlets',
      description: 'Use smart power strips to shut down standby devices like TVs and computer monitors.',
      savingValue: 20,
      icon: 'ToggleRight',
      adopted: false,
    });
  }

  // Sort by potential savings descending
  return recommendations.sort((a, b) => b.savingValue - a.savingValue);
}
