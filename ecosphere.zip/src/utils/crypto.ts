/**
 * Secure State Storage Utility using Web Crypto API (SubtleCrypto)
 * Implements AES-GCM 256-bit encryption for local storage state parameters.
 */

const KEY_STORAGE_NAME = 'cp_secure_key';

/**
 * Gets the encryption key from localStorage (or creates a new one if not found).
 */
async function getOrCreateKey(): Promise<CryptoKey> {
  const storedKeyJwk = localStorage.getItem(KEY_STORAGE_NAME);
  
  if (storedKeyJwk) {
    try {
      const jwk = JSON.parse(atob(storedKeyJwk));
      return await window.crypto.subtle.importKey(
        'jwk',
        jwk,
        { name: 'AES-GCM', length: 256 },
        true,
        ['encrypt', 'decrypt']
      );
    } catch (e) {
      console.warn('Failed to import existing secure key, generating a new one.', e);
    }
  }

  // Generate a brand new AES-GCM 256-bit key
  const key = await window.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );

  // Export and store it securely
  const exported = await window.crypto.subtle.exportKey('jwk', key);
  localStorage.setItem(KEY_STORAGE_NAME, btoa(JSON.stringify(exported)));
  return key;
}

/**
 * Encrypts a plaintext string and returns a Base64-encoded payload.
 */
export async function encryptData(plaintext: string): Promise<string> {
  try {
    const key = await getOrCreateKey();
    const encoder = new TextEncoder();
    const encodedPlaintext = encoder.encode(plaintext);
    
    // Generate a secure 12-byte initialization vector (IV)
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    
    const ciphertext = await window.crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      encodedPlaintext
    );

    // Combine IV and Ciphertext into a single array
    const combined = new Uint8Array(iv.length + ciphertext.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(ciphertext), iv.length);

    // Convert to Base64
    let binary = '';
    const len = combined.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(combined[i]);
    }
    return btoa(binary);
  } catch (error) {
    console.error('Encryption failed:', error);
    throw error;
  }
}

/**
 * Decrypts a Base64-encoded payload back to plaintext.
 */
export async function decryptData(base64Str: string): Promise<string> {
  try {
    const key = await getOrCreateKey();
    
    // Decode Base64 to binary string
    const binary = atob(base64Str);
    const combined = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      combined[i] = binary.charCodeAt(i);
    }

    if (combined.length < 12) {
      throw new Error('Invalid payload length: too short.');
    }

    const iv = combined.slice(0, 12);
    const ciphertext = combined.slice(12);

    const decrypted = await window.crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      ciphertext
    );

    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
  } catch (error) {
    console.error('Decryption failed:', error);
    throw error;
  }
}
