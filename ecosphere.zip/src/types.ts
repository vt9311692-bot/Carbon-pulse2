import { EstimatorInputs } from './utils/emissionFactors';

export * from './utils/emissionFactors';

export interface HistoryEntry {
  id: number;
  timestamp: string; // ISO 8601 string or Unix timestamp format
  transport: number; // kg CO2e
  energy: number;    // kg CO2e
  diet: number;      // kg CO2e
  waste: number;      // kg CO2e
  total: number;      // kg CO2e
  inputs?: EstimatorInputs; // optional saved raw input values
}

export interface RecommendationAction {
  id: string;
  category: 'transport' | 'energy' | 'diet' | 'waste';
  title: string;
  description: string;
  savingValue: number; // kg CO2e / year saved
  icon: string;
  adopted: boolean;
}
