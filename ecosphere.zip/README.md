# 🌱 CarbonPulse — Real-Time Carbon Footprint & Physics Dashboard

[![Vite](https://img.shields.io/badge/Vite-6.0-646CFF?style=flat&logo=vite)](https://vitejs.dev/)
[![React](https://img.shields.io/badge/React-18.3-61DAFB?style=flat&logo=react)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.2-3178C6?style=flat&logo=typescript)](https://www.typescriptlang.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.30-FF4B4B?style=flat&logo=streamlit)](https://streamlit.io/)
[![SQLite](https://img.shields.io/badge/SQLite-WAL_Mode-003B57?style=flat&logo=sqlite)](https://sqlite.org/)

**CarbonPulse** is a production-grade, double-app environmental monitoring and analytics suite. It enables users to estimate, simulate, and ledger their annual carbon footprint using standard EPA and GHG Protocol factors. The platform offers two interfaces: a high-fidelity **React + TypeScript SPA** featuring a 2D physics engine, and a standalone **Python + Streamlit dashboard**. Both connect to a shared SQLite backend with secure multi-user session scoping.

---

## 🚀 Key Features

*   **Dual UI Architectures**:
    *   **React Web Client**: Built with React 18, Vite, and native CSS. Features custom glassmorphism styling, a high-contrast layout, and fluid performance.
    *   **Streamlit Client**: A standalone Python dashboard ([app.py](file:///Users/mac/Developer/ecosphere/app.py)) featuring real-time SVG charts, comparison gauges, and built-in theme support.
*   **Interactive 2D Canvas Physics Engine**: Models transport, energy, diet, and waste carbon weights as physical blocks with mass proportional to emissions. Adopting offset actions triggers an "Anti-Gravity Vector," attaching exhaust-thrusting green balloons that lift the blocks.
*   **Secure Multi-User Ledgers**: Supports account registration, logins, and guest modes in both apps. Password hashes are generated using `hashlib.sha256` salted with randomized salts. Ledger calculation history is strictly scoped by `user_id`.
*   **SubtleCrypto State Encryption**: Local user state storage inside the React app is encrypted using native AES-GCM (256-bit) via the Web Crypto API, safeguarding cache integrity.
*   **Hardened API Web Server**: Custom Python server ([server.py](file:///Users/mac/Developer/ecosphere/server.py)) running on port `8080`. Enforces directory traversal protection and sets robust HTTP security headers (`Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`).
*   **Accessibility (WCAG 2.1 AA compliant)**: Semantically structured markup, screen reader regions (`aria-live`), full keyboard navigation tab-rings, SVG chart focus labels, and a focus-trapped auth modal.

---

## 🛠️ Technology Stack

*   **Frontend Client**: React 18, TypeScript, Vite, TailwindCSS (for utility structures).
*   **Python Client**: Streamlit 1.30.
*   **Backend Server**: Python `http.server` APIs, HMAC token signature validation.
*   **Storage**: SQLite (`carbonpulse.db`) running in Write-Ahead Log (WAL) mode for concurrency.
*   **Crypto Core**: Web Crypto API (SubtleCrypto) + Python `hashlib`.

---

## 📂 Project Structure

```text
├── app.py                      # Standalone Streamlit Application
├── server.py                   # Custom HTTP Web & API Server
├── requirements.txt            # Python Dependencies
├── package.json                # React/Vite Package Setup
├── tsconfig.json               # TypeScript Compiler Config
├── vite.config.ts              # Vite Bundler Setup
├── .streamlit/
│   └── config.toml             # Streamlit Telemetry & CORS Settings
├── src/
│   ├── components/             # React SPA Interface Components
│   │   ├── Dashboard.tsx       # Gauge indicators & Chart aggregates
│   │   ├── EstimatorForm.tsx   # Sanitized numeric calculations form
│   │   ├── EcosystemSimulation.tsx # 2D Physics canvas simulation loop
│   │   ├── HistoryLedger.tsx   # Sparkline and ledger records table
│   │   ├── SignInModal.tsx     # Secure user session auth dialog
│   │   └── Layout.tsx          # Main grid assembler
│   ├── utils/
│   │   ├── crypto.ts           # AES-GCM 256 SubtleCrypto handlers
│   │   └── emissionFactors.ts  # GHG Protocol mathematical formulas
│   └── tests/
│       ├── run.ts              # Native Test runner script
│       ├── calculation.test.ts # Emission calculation test assertions
│       └── simulation.test.ts  # Crypto and user validation checks
```

---

## ⚡ Quick Start

### 1. Python Streamlit Dashboard
Launch the standalone Streamlit app:
```bash
# Activate virtual environment
source .venv/bin/activate

# Start Streamlit server
streamlit run app.py
```
Open your browser at **[http://localhost:8501](http://localhost:8501)**.

### 2. React SPA + API Server
Install dependencies, compile the production assets, and start the custom server:
```bash
# 1. Install Node modules & build production assets
npm install
npm run build

# 2. Run the HTTP & API Server (binds to port 8080)
python3 server.py
```
Open your browser at **[http://localhost:8080](http://localhost:8080)**.

---

## 🧪 Testing Suite
We utilize Node's native test runner for minimal overhead and seamless testing in localized environments:
```bash
npm run test
```
*All 17 tests verify formula conversions, sanitization boundaries, Web Crypto encryption cycles, and password hashing security.*
