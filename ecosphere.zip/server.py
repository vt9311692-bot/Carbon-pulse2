import os
import json
import sqlite3
import mimetypes
import hashlib
import hmac
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

DB_FILE = "carbonpulse.db"
PORT = 8080
STATIC_DIR = "dist"

# Generate a secure server secret at startup to sign tokens
SERVER_SECRET = os.urandom(32).hex()

def init_db():
    """Initializes the SQLite database, users, and calculations ledger tables."""
    conn = sqlite3.connect(DB_FILE, timeout=30.0)
    cursor = conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL;")
    
    # Create users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL
        )
    """)
    
    # Create calculations table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS calculations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            transport REAL NOT NULL,
            energy REAL NOT NULL,
            diet REAL NOT NULL,
            waste REAL NOT NULL,
            total REAL NOT NULL,
            user_id INTEGER,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Safely try to append user_id column to calculations if database existed previously
    try:
        cursor.execute("ALTER TABLE calculations ADD COLUMN user_id INTEGER REFERENCES users(id);")
    except sqlite3.OperationalError:
        # Column already exists
        pass

    conn.commit()
    conn.close()
    print(f"📁 SQLite database '{DB_FILE}' initialized successfully in WAL mode.")

def generate_auth_token(user_id, email):
    """Generates a secure, tamper-proof signature token for sessions."""
    msg = f"{user_id}:{email}"
    signature = hmac.new(
        SERVER_SECRET.encode('utf-8'),
        msg.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    return f"{user_id}:{email}:{signature}"

def verify_auth_token(token):
    """Verifies a signature token and returns (user_id, email) or (None, None)."""
    if not token:
        return None, None
    try:
        parts = token.split(':')
        if len(parts) != 3:
            return None, None
        user_id_str, email, signature = parts
        user_id = int(user_id_str)
        
        expected_signature = hmac.new(
            SERVER_SECRET.encode('utf-8'),
            f"{user_id}:{email}".encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        if hmac.compare_digest(expected_signature, signature):
            return user_id, email
    except Exception:
        pass
    return None, None

class EcosphereAPIHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS for development
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        # Security headers
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('X-XSS-Protection', '1; mode=block')
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self' http://localhost:8080 http://localhost:3000 ws: wss:;")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def get_authenticated_user(self):
        """Helper to get authenticated user details from headers."""
        auth_header = self.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            token = auth_header[7:]
            return verify_auth_token(token)
        return None, None

    def do_GET(self):
        parsed_url = urlparse(self.path)
        
        # Route API Requests
        if parsed_url.path == '/api/history':
            self.handle_get_history()
            return
            
        # Serve Static Files
        self.serve_static_files(parsed_url.path)

    def do_POST(self):
        parsed_url = urlparse(self.path)
        
        if parsed_url.path == '/api/history':
            self.handle_post_history()
            return
        elif parsed_url.path == '/api/register':
            self.handle_post_register()
            return
        elif parsed_url.path == '/api/login':
            self.handle_post_login()
            return
            
        self.send_error(404, "Endpoint not found")

    def do_DELETE(self):
        parsed_url = urlparse(self.path)
        
        if parsed_url.path == '/api/history':
            self.handle_delete_history(parsed_url.query)
            return
            
        self.send_error(404, "Endpoint not found")

    def handle_post_register(self):
        """Creates a new user profile with secure salt-hashed password storage."""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            body = json.loads(post_data.decode('utf-8'))
            
            email = body.get('email', '').strip().lower()
            password = body.get('password', '')
            
            if not email or '@' not in email:
                self.send_error(400, "Invalid email format")
                return
            if len(password) < 6:
                self.send_error(400, "Password must be at least 6 characters long")
                return
                
            salt = os.urandom(16).hex()
            password_hash = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
            
            conn = sqlite3.connect(DB_FILE, timeout=30.0)
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    INSERT INTO users (email, password_hash, salt)
                    VALUES (?, ?, ?)
                """, (email, password_hash, salt))
                conn.commit()
                user_id = cursor.lastrowid
            except sqlite3.IntegrityError:
                self.send_error(400, "Email address already registered")
                return
            finally:
                conn.close()
                
            token = generate_auth_token(user_id, email)
            response_payload = json.dumps({
                "status": "success",
                "email": email,
                "token": token
            }).encode('utf-8')
            
            self.send_response(201)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(response_payload)))
            self.end_headers()
            self.wfile.write(response_payload)
            
        except Exception as e:
            self.send_error(500, f"Error during registration: {str(e)}")

    def handle_post_login(self):
        """Verifies credentials and returns signed session token."""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            body = json.loads(post_data.decode('utf-8'))
            
            email = body.get('email', '').strip().lower()
            password = body.get('password', '')
            
            conn = sqlite3.connect(DB_FILE, timeout=30.0)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT id, password_hash, salt FROM users WHERE email = ?", (email,))
            user = cursor.fetchone()
            conn.close()
            
            if not user:
                self.send_error(401, "Invalid email or password")
                return
                
            input_hash = hashlib.sha256((password + user["salt"]).encode('utf-8')).hexdigest()
            if input_hash != user["password_hash"]:
                self.send_error(401, "Invalid email or password")
                return
                
            token = generate_auth_token(user["id"], email)
            response_payload = json.dumps({
                "status": "success",
                "email": email,
                "token": token
            }).encode('utf-8')
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(response_payload)))
            self.end_headers()
            self.wfile.write(response_payload)
            
        except Exception as e:
            self.send_error(500, f"Error processing login request: {str(e)}")

    def handle_get_history(self):
        """Retrieves history ledger entries, scoped to user if logged in, or guest."""
        try:
            user_id, _ = self.get_authenticated_user()
            
            conn = sqlite3.connect(DB_FILE, timeout=30.0)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if user_id is not None:
                cursor.execute("SELECT * FROM calculations WHERE user_id = ? ORDER BY timestamp DESC", (user_id,))
            else:
                cursor.execute("SELECT * FROM calculations WHERE user_id IS NULL ORDER BY timestamp DESC")
                
            rows = cursor.fetchall()
            
            history = []
            for row in rows:
                history.append({
                    "id": row["id"],
                    "timestamp": row["timestamp"],
                    "transport": row["transport"],
                    "energy": row["energy"],
                    "diet": row["diet"],
                    "waste": row["waste"],
                    "total": row["total"]
                })
            conn.close()
            
            response_data = json.dumps(history).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(response_data)))
            self.end_headers()
            self.wfile.write(response_data)
            
        except Exception as e:
            self.send_error(500, f"Database error: {str(e)}")

    def handle_post_history(self):
        """Saves a new calculation entry, scoped to the current user_id (if authenticated)."""
        try:
            user_id, _ = self.get_authenticated_user()
            
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            entry = json.loads(post_data.decode('utf-8'))
            
            # Validate input properties
            required_fields = ["transport", "energy", "diet", "waste", "total"]
            if not all(field in entry for field in required_fields):
                self.send_error(400, "Missing required calculation values")
                return

            timestamp = datetime.now().isoformat()
            
            conn = sqlite3.connect(DB_FILE, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO calculations (timestamp, transport, energy, diet, waste, total, user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (timestamp, entry["transport"], entry["energy"], entry["diet"], entry["waste"], entry["total"], user_id))
            
            inserted_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            response_payload = json.dumps({
                "id": inserted_id,
                "timestamp": timestamp,
                "status": "success"
            }).encode('utf-8')
            
            self.send_response(201)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(response_payload)))
            self.end_headers()
            self.wfile.write(response_payload)
            
        except Exception as e:
            self.send_error(500, f"Error processing database write: {str(e)}")

    def handle_delete_history(self, query_string):
        """Deletes a ledger entry by ID, scoped by user_id for security checks."""
        try:
            user_id, _ = self.get_authenticated_user()
            
            params = parse_qs(query_string)
            entry_id = params.get('id', [None])[0]
            
            if not entry_id:
                self.send_error(400, "Missing entry ID parameter")
                return
                
            conn = sqlite3.connect(DB_FILE, timeout=30.0)
            cursor = conn.cursor()
            
            if user_id is not None:
                cursor.execute("DELETE FROM calculations WHERE id = ? AND user_id = ?", (entry_id, user_id))
            else:
                cursor.execute("DELETE FROM calculations WHERE id = ? AND user_id IS NULL", (entry_id,))
                
            conn.commit()
            conn.close()
            
            response_payload = json.dumps({"status": "success", "id": entry_id}).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(response_payload)))
            self.end_headers()
            self.wfile.write(response_payload)
            
        except Exception as e:
            self.send_error(500, f"Database deletion error: {str(e)}")
    def serve_static_files(self, path):
        """Serves compiled frontend files from dist directory."""
        # Sanitize path to avoid path traversal vulnerability
        clean_path = path.lstrip('/')
        if not clean_path or clean_path == '':
            clean_path = 'index.html'
            
        # Prevent traversal by checking directory prefix
        abs_static_dir = os.path.abspath(STATIC_DIR)
        file_path = os.path.abspath(os.path.join(abs_static_dir, clean_path))
        
        if not file_path.startswith(abs_static_dir):
            self.send_error(403, "Access Denied")
            return
            
        # Fallback to index.html for SPA client-side routing
        if not os.path.exists(file_path) or os.path.isdir(file_path):
            file_path = os.path.join(abs_static_dir, 'index.html')
            
        if not os.path.exists(file_path):
            self.send_error(404, "Static file assets not built. Run 'npm run build' first.")
            return

        # Determine MIME Type
        mime_type, _ = mimetypes.guess_type(file_path)
        if file_path.endswith('.js'):
            mime_type = 'application/javascript'
        elif file_path.endswith('.css'):
            mime_type = 'text/css'
        elif not mime_type:
            mime_type = 'application/octet-stream'

        try:
            with open(file_path, 'rb') as f:
                content = f.read()
                
            self.send_response(200)
            self.send_header('Content-Type', mime_type)
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Error reading asset file: {str(e)}")

def run_server():
    init_db()
    server_address = ('', PORT)
    httpd = HTTPServer(server_address, EcosphereAPIHandler)
    print(f"🚀 CarbonPulse API and Asset Server running on http://localhost:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping CarbonPulse server...")
        httpd.server_close()

if __name__ == '__main__':
    run_server()
